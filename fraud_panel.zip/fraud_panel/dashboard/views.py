from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Sum, Avg, Q
from django.utils import timezone
from datetime import timedelta
from bots.models import BotInstance

@login_required
def index(request):
    # Получаем реальные данные из базы
    try:
        from accounts.models import Account
        from payments.models import FinancialLog

        # Основная статистика
        total_accounts = Account.objects.filter(owner=request.user).count()
        total_bots = BotInstance.objects.filter(owner=request.user, is_active=True).count()

        # Финансовая статистика за последние 30 дней
        last_30_days = timezone.now() - timedelta(days=30)
        financial_stats = FinancialLog.objects.filter(
            owner=request.user,
            timestamp__gte=last_30_days,
            status='COMPLETED'
        ).aggregate(
            total_income=Sum('amount', filter=Q(action='EARNED')),
            total_withdrawn=Sum('amount', filter=Q(action='WITHDRAWN'))
        )

        total_income = financial_stats['total_income'] or 0
        total_withdrawn = financial_stats['total_withdrawn'] or 0

        # Статистика валидности
        validity_stats = Account.objects.filter(owner=request.user).aggregate(
            total=Count('id'),
            valid=Count('id', filter=Q(is_valid=True))
        )

        if validity_stats['total'] > 0:
            validity_percentage = (validity_stats['valid'] / validity_stats['total']) * 100
        else:
            validity_percentage = 0

        # Аккаунты за последние 7 дней для графика
        chart_data = []
        chart_labels = []

        for i in range(7):
            day = timezone.now() - timedelta(days=6 - i)
            day_start = day.replace(hour=0, minute=0, second=0, microsecond=0)
            day_end = day.replace(hour=23, minute=59, second=59, microsecond=999999)

            day_accounts = Account.objects.filter(
                owner=request.user,
                created_at__range=[day_start, day_end]
            ).count()

            chart_data.append(day_accounts)
            chart_labels.append(day.strftime('%d.%m'))

        # Топ источников
        top_sources = Account.objects.filter(owner=request.user).values(
            'log_source'
        ).annotate(
            count=Count('id')
        ).order_by('-count')[:5]

        # Последние аккаунты
        recent_accounts = Account.objects.filter(owner=request.user).order_by('-created_at')[:10]

    except ImportError:
        # Если модели еще не созданы, используем фиктивные данные
        total_accounts = 0
        total_bots = 0
        total_income = 0
        total_withdrawn = 0
        validity_percentage = 0
        chart_data = [0, 0, 0, 0, 0, 0, 0]
        chart_labels = ['01.12', '02.12', '03.12', '04.12', '05.12', '06.12', '07.12']
        top_sources = []
        recent_accounts = []

    context = {
        'total_accounts': total_accounts,
        'total_bots': total_bots,
        'total_income': total_income,
        'total_withdrawn': total_withdrawn,
        'validity_percentage': round(validity_percentage, 1),
        'chart_data': chart_data,
        'chart_labels': chart_labels,
        'top_sources': top_sources,
        'recent_accounts': recent_accounts,
    }

    return render(request, 'dashboard/index.html', context)

