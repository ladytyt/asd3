from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, HttpResponse
from django.utils import timezone
from django.db.models import Q
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
import json
import csv
import asyncio
import os
import requests

from .models import Account, AccountLog, UserBot, AuthorizationSession
from .services import (
    sync_check_telegram_account, sync_create_telegram_session,
    sync_check_with_bot, sync_start_authorization,
    sync_complete_authorization, sync_complete_2fa,
    verify_bot_token
)
from .telegram_bot_service import TelegramBotService


# Главная страница с упрощенной аутентификацией
def simple_main(request):
    """Упрощенная главная страница"""
    return render(request, 'accounts/simple_main.html')


def simple_login(request):
    """Простая аутентификация"""
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('accounts:dashboard')
        else:
            return render(request, 'accounts/simple_main.html', {
                'error': 'Неверные учетные данные'
            })

    return redirect('accounts:simple_main')


def logout_view(request):
    """Выход из системы"""
    logout(request)
    return redirect('accounts:simple_main')


# Панель управления аккаунтами
@login_required
def index(request):
    """Главная страница управления аккаунтами"""
    accounts = Account.objects.filter(owner=request.user)

    # Фильтрация
    country_filter = request.GET.get('country')
    status_filter = request.GET.get('status')
    source_filter = request.GET.get('source')

    if country_filter:
        accounts = accounts.filter(country=country_filter)
    if status_filter:
        accounts = accounts.filter(status=status_filter)
    if source_filter:
        accounts = accounts.filter(log_source__icontains=source_filter)

    context = {
        'accounts': accounts,
        'total_accounts': Account.objects.filter(owner=request.user).count(),
        'valid_accounts': Account.objects.filter(owner=request.user, is_valid=True).count(),
    }

    return render(request, 'accounts/index.html', context)


# Проверка аккаунтов
@login_required
def check_accounts(request):
    """Проверка аккаунтов через системного бота"""
    if request.method == 'POST':
        account_ids = request.POST.getlist('account_ids[]')
        accounts = Account.objects.filter(id__in=account_ids, owner=request.user)

        results = []
        for account in accounts:
            try:
                # Используем синхронную проверку
                result = sync_check_telegram_account(account.phone_number, account.password)

                # Обновление статуса аккаунта
                account.is_valid = result['status'] == 'VALID'
                account.is_premium = result.get('premium', False)
                account.username = result.get('username', '')
                account.last_check = timezone.now()

                if result['status'] == 'VALID':
                    account.status = 'ACTIVE'
                elif result['status'] in ['BLOCKED', 'INVALID']:
                    account.status = 'INVALID'

                account.save()

                # Создание лога
                AccountLog.objects.create(
                    account=account,
                    action='ACCOUNT_CHECK',
                    details=f"Результат проверки: {result['status']}. {result.get('message', '')}"
                )

                results.append({
                    'id': account.id,
                    'status': result['status'],
                    'message': result.get('message', ''),
                    'username': result.get('username', ''),
                    'is_premium': result.get('premium', False)
                })

            except Exception as e:
                results.append({
                    'id': account.id,
                    'status': 'ERROR',
                    'message': str(e)
                })

        return JsonResponse({'success': True, 'results': results})

    return JsonResponse({'success': False, 'error': 'Invalid request method'})


@login_required
def check_accounts_with_bot(request):
    """Проверка аккаунтов через пользовательского бота"""
    if request.method == 'POST':
        account_ids = request.POST.getlist('account_ids[]')
        bot_id = request.POST.get('bot_id')

        accounts = Account.objects.filter(id__in=account_ids, owner=request.user)

        try:
            user_bot = UserBot.objects.get(id=bot_id, owner=request.user)
        except UserBot.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'Бот не найден'})

        results = []
        for account in accounts:
            try:
                result = sync_check_with_bot(
                    account.phone_number,
                    account.password,
                    user_bot
                )

                # Обновляем статус аккаунта
                account.is_valid = result['status'] == 'VALID'
                account.is_premium = result.get('premium', False)
                account.username = result.get('username', '')
                account.last_check = timezone.now()

                if result['status'] == 'VALID':
                    account.status = 'ACTIVE'
                elif result['status'] in ['BLOCKED', 'INVALID']:
                    account.status = 'INVALID'

                account.save()

                # Создание лога
                AccountLog.objects.create(
                    account=account,
                    action='ACCOUNT_CHECK_WITH_BOT',
                    details=f"Проверка через бота {user_bot.name}. Результат: {result['status']}. {result.get('message', '')}"
                )

                # Обновляем статистику бота
                user_bot.accounts_checked += 1
                user_bot.last_used = timezone.now()
                user_bot.save()

                results.append({
                    'id': account.id,
                    'status': result['status'],
                    'message': result.get('message', ''),
                    'username': result.get('username', ''),
                    'is_premium': result.get('premium', False)
                })

            except Exception as e:
                results.append({
                    'id': account.id,
                    'status': 'ERROR',
                    'message': str(e)
                })

        return JsonResponse({'success': True, 'results': results})

    return JsonResponse({'success': False, 'error': 'Invalid request method'})


# Экспорт данных
@login_required
def export_json(request):
    """Экспорт аккаунтов в JSON"""
    account_ids = request.GET.getlist('account_ids[]')
    if not account_ids:
        accounts = Account.objects.filter(owner=request.user)
    else:
        accounts = Account.objects.filter(id__in=account_ids, owner=request.user)

    accounts_data = []
    for account in accounts:
        accounts_data.append({
            'id': account.id,
            'phone_number': account.phone_number,
            'country': account.country,
            'status': account.status,
            'is_valid': account.is_valid,
            'is_premium': account.is_premium,
            'username': account.username,
            'log_source': account.log_source,
            'created_at': account.created_at.isoformat(),
            'last_activity': account.last_activity.isoformat() if account.last_activity else None,
        })

    response = HttpResponse(
        json.dumps(accounts_data, ensure_ascii=False, indent=2),
        content_type='application/json'
    )
    response['Content-Disposition'] = 'attachment; filename="accounts_export.json"'
    return response


@login_required
def export_csv(request):
    """Экспорт аккаунтов в CSV"""
    account_ids = request.GET.getlist('account_ids[]')
    if not account_ids:
        accounts = Account.objects.filter(owner=request.user)
    else:
        accounts = Account.objects.filter(id__in=account_ids, owner=request.user)

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="accounts_export.csv"'

    writer = csv.writer(response)
    writer.writerow([
        'Phone Number', 'Country', 'Status', 'Valid', 'Premium',
        'Username', 'Source', 'Created At', 'Last Activity'
    ])

    for account in accounts:
        writer.writerow([
            account.phone_number,
            account.country,
            account.status,
            'Yes' if account.is_valid else 'No',
            'Yes' if account.is_premium else 'No',
            account.username or '',
            account.log_source,
            account.created_at.strftime('%Y-%m-%d %H:%M'),
            account.last_activity.strftime('%Y-%m-%d %H:%M') if account.last_activity else ''
        ])

    return response


# Управление аккаунтами
@login_required
def edit_account(request, account_id):
    """Редактирование аккаунта"""
    account = get_object_or_404(Account, id=account_id, owner=request.user)

    if request.method == 'POST':
        try:
            account.phone_number = request.POST.get('phone_number', account.phone_number)
            account.country = request.POST.get('country', account.country)
            account.password = request.POST.get('password', account.password)
            account.two_fa_password = request.POST.get('two_fa_password', account.two_fa_password)
            account.log_source = request.POST.get('log_source', account.log_source)
            account.admin_info = request.POST.get('admin_info', account.admin_info)
            account.save()

            AccountLog.objects.create(
                account=account,
                action='ACCOUNT_EDIT',
                details='Аккаунт отредактирован через веб-интерфейс'
            )

            return JsonResponse({'success': True})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})

    return JsonResponse({'success': False, 'error': 'Invalid request method'})


@login_required
def get_account_data(request, account_id):
    """Получение данных аккаунта для редактирования"""
    account = get_object_or_404(Account, id=account_id, owner=request.user)
    return JsonResponse({
        'phone_number': account.phone_number,
        'country': account.country,
        'password': account.password,
        'two_fa_password': account.two_fa_password,
        'log_source': account.log_source,
        'admin_info': account.admin_info,
    })


@login_required
def add_account(request):
    """Добавление нового аккаунта"""
    if request.method == 'POST':
        try:
            phone_number = request.POST.get('phone_number')
            country = request.POST.get('country')
            password = request.POST.get('password')
            two_fa_password = request.POST.get('two_fa_password')
            log_source = request.POST.get('log_source', 'Manual')

            # Создаем аккаунт
            account = Account.objects.create(
                owner=request.user,
                phone_number=phone_number,
                country=country,
                password=password,
                two_fa_password=two_fa_password,
                log_source=log_source,
                is_valid=False,
                status='ACTIVE'
            )

            AccountLog.objects.create(
                account=account,
                action='ACCOUNT_CREATED',
                details='Аккаунт добавлен через веб-интерфейс'
            )

            messages.success(request, 'Аккаунт успешно добавлен')
            return redirect('accounts:dashboard')

        except Exception as e:
            messages.error(request, f'Ошибка при добавлении аккаунта: {str(e)}')
            return redirect('accounts:dashboard')

    return JsonResponse({'success': False, 'error': 'Invalid request method'})


@login_required
def delete_accounts(request):
    """Удаление аккаунтов"""
    if request.method == 'POST':
        account_ids = request.POST.getlist('account_ids[]')
        accounts = Account.objects.filter(id__in=account_ids, owner=request.user)

        deleted_count = accounts.count()

        # Создание логов перед удалением
        for account in accounts:
            AccountLog.objects.create(
                account=account,
                action='ACCOUNT_DELETED',
                details='Аккаунт удален из системы'
            )

        accounts.delete()

        return JsonResponse({
            'success': True,
            'message': f'Удалено {deleted_count} аккаунтов'
        })

    return JsonResponse({'success': False, 'error': 'Invalid request method'})


# Управление ботами
@login_required
def bot_management(request):
    """Управление ботами пользователя"""
    user_bots = UserBot.objects.filter(owner=request.user)

    if request.method == 'POST':
        action = request.POST.get('action')

        if action == 'add_bot':
            bot_name = request.POST.get('bot_name')
            bot_token = request.POST.get('bot_token')

            # Проверяем токен
            if verify_bot_token(bot_token):
                # Проверяем, не добавлен ли уже бот с таким токеном
                if UserBot.objects.filter(bot_token=bot_token, owner=request.user).exists():
                    messages.error(request, 'Бот с таким токеном уже добавлен')
                else:
                    # Создаем бота
                    user_bot = UserBot.objects.create(
                        owner=request.user,
                        name=bot_name,
                        bot_token=bot_token
                    )
                    messages.success(request, 'Бот успешно добавлен!')
            else:
                messages.error(request, 'Неверный токен бота')

        elif action == 'delete_bot':
            bot_id = request.POST.get('bot_id')
            try:
                bot = UserBot.objects.get(id=bot_id, owner=request.user)
                bot.delete()
                messages.success(request, 'Бот удален')
            except UserBot.DoesNotExist:
                messages.error(request, 'Бот не найден')

    return render(request, 'accounts/bot_management.html', {
        'user_bots': user_bots
    })


# Авторизация через Telegram бота
@login_required
def start_authorization(request, account_id):
    """Начало процесса авторизации через бота"""
    account = get_object_or_404(Account, id=account_id, owner=request.user)

    if request.method == 'POST':
        bot_id = request.POST.get('bot_id')
        chat_id = request.POST.get('chat_id')  # ID чата с ботом

        try:
            user_bot = UserBot.objects.get(id=bot_id, owner=request.user)

            # Получаем информацию о боте
            bot_service = TelegramBotService(user_bot.bot_token)
            bot_info_url = f"https://api.telegram.org/bot{user_bot.bot_token}/getMe"
            bot_info_response = requests.get(bot_info_url)

            if not bot_info_response.json().get('ok'):
                return JsonResponse({
                    'success': False,
                    'error': 'Неверный токен бота'
                })

            # Начинаем авторизацию
            result = sync_start_authorization(
                account.phone_number,
                user_bot,
                chat_id
            )

            if result['success']:
                # Сохраняем ID сессии авторизации в аккаунте
                account.auth_session_id = result['auth_session_id']
                account.save()

                return JsonResponse({
                    'success': True,
                    'message': result['message'],
                    'bot_username': bot_info_response.json()['result']['username']
                })
            else:
                return JsonResponse({
                    'success': False,
                    'error': result['error']
                })

        except UserBot.DoesNotExist:
            return JsonResponse({
                'success': False,
                'error': 'Бот не найден'
            })
        except Exception as e:
            return JsonResponse({
                'success': False,
                'error': f'Ошибка: {str(e)}'
            })

    return JsonResponse({'success': False, 'error': 'Invalid request'})


@login_required
def get_auth_status(request, account_id):
    """Проверка статуса авторизации"""
    account = get_object_or_404(Account, id=account_id, owner=request.user)

    if hasattr(account, 'auth_session_id') and account.auth_session_id:
        try:
            auth_session = AuthorizationSession.objects.get(
                id=account.auth_session_id,
                user=request.user
            )

            return JsonResponse({
                'success': True,
                'status': auth_session.status,
                'completed': auth_session.status == 'COMPLETED'
            })
        except AuthorizationSession.DoesNotExist:
            pass

    return JsonResponse({
        'success': True,
        'status': 'NOT_STARTED',
        'completed': False
    })


@login_required
def create_session(request, account_id):
    """Создание сессии (устаревший метод - оставлен для совместимости)"""
    account = get_object_or_404(Account, id=account_id, owner=request.user)

    if request.method == 'POST':
        try:
            # Используем системного бота по умолчанию
            result = sync_create_telegram_session(account.phone_number, account.password)

            if result['success']:
                AccountLog.objects.create(
                    account=account,
                    action='SESSION_CREATED',
                    details='Сессия Telegram успешно создана'
                )
                return JsonResponse({'success': True, 'message': 'Сессия создана успешно'})
            else:
                return JsonResponse({'success': False, 'error': result.get('message', 'Unknown error')})

        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})

    return JsonResponse({'success': False, 'error': 'Invalid request method'})


# Webhook для Telegram бота
from django.views.decorators.csrf import csrf_exempt
from .telegram_webhook import telegram_webhook


# Дополнительные утилиты
def create_test_user(request):
    """Создание тестового пользователя (для разработки)"""
    if not User.objects.filter(username='admin').exists():
        User.objects.create_user(
            username='admin',
            password='admin123',
            is_staff=True,
            is_superuser=True
        )
        return JsonResponse({'success': True, 'message': 'Тестовый пользователь создан: admin/admin123'})
    return JsonResponse({'success': False, 'message': 'Пользователь уже существует'})


# Резервные представления для совместимости
def main_page(request):
    """Главная страница с Telegram WebApp (резервная)"""
    return render(request, 'accounts/main.html')


@csrf_exempt
def telegram_login(request):
    """Вход через Telegram WebApp (резервный)"""
    # Это упрощенная версия - в реальном приложении нужно реализовать проверку подписи
    if request.method == 'POST':
        try:
            user_data = request.POST.get('user_data', {})

            # Здесь должна быть проверка подписи Telegram
            # Для тестирования создаем/находим пользователя
            telegram_id = user_data.get('id')
            first_name = user_data.get('first_name', '')
            username = user_data.get('username', '')

            if telegram_id:
                user, created = User.objects.get_or_create(
                    username=f"tg_{telegram_id}",
                    defaults={
                        'first_name': first_name,
                        'password': User.objects.make_random_password()
                    }
                )

                login(request, user)
                return JsonResponse({
                    'success': True,
                    'user': {
                        'username': user.username,
                        'first_name': user.first_name
                    }
                })

        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})

    return JsonResponse({'success': False, 'error': 'Invalid request'})