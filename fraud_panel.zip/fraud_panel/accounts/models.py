from django.db import models
from django.contrib.auth.models import User



class Account(models.Model):
    COUNTRY_CHOICES = [
        ('US', 'USA'),
        ('RU', 'Russia'),
        ('UA', 'Ukraine'),
        ('KZ', 'Kazakhstan'),
        ('BY', 'Belarus'),
        ('OTHER', 'Other'),
    ]

    STATUS_CHOICES = [
        ('ACTIVE', 'Active'),
        ('BLOCKED', 'Blocked'),
        ('SPAM_BLOCKED', 'Spam Blocked'),
        ('INVALID', 'Invalid'),
    ]

    owner = models.ForeignKey(User, on_delete=models.CASCADE)
    phone_number = models.CharField(max_length=20, verbose_name="Номер телефона")
    country = models.CharField(max_length=10, choices=COUNTRY_CHOICES, verbose_name="Страна")
    is_spam_blocked = models.BooleanField(default=False, verbose_name="Спам блок")
    market_status = models.CharField(max_length=100, blank=True, verbose_name="Статус на маркете")
    is_premium = models.BooleanField(default=False, verbose_name="Премиум")
    log_source = models.CharField(max_length=100, verbose_name="Источник лога")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Время прихода")
    is_valid = models.BooleanField(default=False, verbose_name="Валидность")
    password = models.CharField(max_length=100, blank=True, verbose_name="Пароль")
    two_fa_password = models.CharField(max_length=100, blank=True, verbose_name="Пароль 2FA")

    # Дополнительные поля
    admin_info = models.TextField(blank=True, verbose_name="Инфа по админкам")
    last_activity = models.DateTimeField(auto_now=True, verbose_name="Последняя активность")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='ACTIVE', verbose_name="Статус")
    session_file = models.FileField(upload_to='sessions/', blank=True, null=True)
    last_check = models.DateTimeField(null=True, blank=True)
    username = models.CharField(max_length=100, blank=True)

    def get_session_path(self):
        if self.session_file:
            return self.session_file.path
        return f'sessions/{self.phone_number}.session'

    def __str__(self):
        return f"{self.phone_number} ({self.country})"

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Аккаунт'
        verbose_name_plural = 'Аккаунты'


class AccountLog(models.Model):
    account = models.ForeignKey(Account, on_delete=models.CASCADE, related_name='logs')
    action = models.CharField(max_length=100, verbose_name="Действие")
    details = models.TextField(blank=True, verbose_name="Детали")
    timestamp = models.DateTimeField(auto_now_add=True, verbose_name="Время")

    def __str__(self):
        return f"{self.account.phone_number} - {self.action}"

    class Meta:
        ordering = ['-timestamp']


class UserBot(models.Model):
    owner = models.ForeignKey(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=100, verbose_name="Название бота")
    bot_token = models.CharField(max_length=200, verbose_name="Токен бота")
    is_active = models.BooleanField(default=True, verbose_name="Активен")
    created_at = models.DateTimeField(auto_now_add=True)

    # Статистика
    accounts_checked = models.IntegerField(default=0, verbose_name="Проверено аккаунтов")
    last_used = models.DateTimeField(null=True, blank=True, verbose_name="Последнее использование")

    def __str__(self):
        return f"{self.name} ({self.owner.username})"

    class Meta:
        verbose_name = 'Бот пользователя'
        verbose_name_plural = 'Боты пользователей'


class BotSession(models.Model):
    bot = models.ForeignKey(UserBot, on_delete=models.CASCADE)
    account = models.ForeignKey(Account, on_delete=models.CASCADE)
    session_data = models.TextField(verbose_name="Данные сессии")
    is_active = models.BooleanField(default=True, verbose_name="Активна")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.bot.name} - {self.account.phone_number}"

    class Meta:
        verbose_name = 'Сессия бота'
        verbose_name_plural = 'Сессии ботов'


class AuthorizationSession(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    phone_number = models.CharField(max_length=20)
    bot = models.ForeignKey(UserBot, on_delete=models.CASCADE)
    phone_code_hash = models.CharField(max_length=200)
    code = models.CharField(max_length=10, blank=True)  # Текущий введенный код
    max_attempts = models.IntegerField(default=5)
    attempts = models.IntegerField(default=0)
    status = models.CharField(max_length=20, default='WAITING_CODE')  # WAITING_CODE, COMPLETED, FAILED
    created_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.phone_number} - {self.status}"

    def is_expired(self):
        return (timezone.now() - self.created_at).seconds > 300  # 5 минут

    class Meta:
        verbose_name = 'Сессия авторизации'
        verbose_name_plural = 'Сессии авторизации'