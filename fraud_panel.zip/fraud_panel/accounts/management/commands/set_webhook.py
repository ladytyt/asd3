from django.core.management.base import BaseCommand
import requests
from django.conf import settings


class Command(BaseCommand):
    help = 'Set up Telegram webhook'

    def handle(self, *args, **options):
        for user_bot in UserBot.objects.all():
            webhook_url = f"https://yourdomain.com/accounts/webhook/telegram/"

            set_webhook_url = f'https://api.telegram.org/bot{user_bot.bot_token}/setWebhook'
            response = requests.post(set_webhook_url, data={
                'url': webhook_url
            })

            if response.json().get('ok'):
                self.stdout.write(
                    self.style.SUCCESS(f'Webhook configured for {user_bot.name}')
                )
            else:
                self.stdout.write(
                    self.style.ERROR(f'Failed to configure webhook for {user_bot.name}')
                )