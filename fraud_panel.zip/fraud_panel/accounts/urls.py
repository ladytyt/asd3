from django.urls import path
from . import views
from .telegram_webhook import telegram_webhook

app_name = 'accounts'

urlpatterns = [
    path('', views.simple_main, name='index'),  # Главная страница accounts
    path('login/', views.simple_login, name='simple_login'),
    path('dashboard/', views.index, name='dashboard'),
    path('check/', views.check_accounts, name='check_accounts'),
    path('check-with-bot/', views.check_accounts_with_bot, name='check_accounts_with_bot'),
    path('export/json/', views.export_json, name='export_json'),
    path('export/csv/', views.export_csv, name='export_csv'),
    path('edit/<int:account_id>/', views.edit_account, name='edit_account'),
    path('get/<int:account_id>/', views.get_account_data, name='get_account_data'),
    path('session/<int:account_id>/', views.create_session, name='create_session'),
    path('delete/', views.delete_accounts, name='delete_accounts'),
    path('add/', views.add_account, name='add_account'),
    path('bots/', views.bot_management, name='bot_management'),
    path('auth/start/<int:account_id>/', views.start_authorization, name='start_authorization'),
    path('auth/status/<int:account_id>/', views.get_auth_status, name='get_auth_status'),
    path('webhook/telegram/', telegram_webhook, name='telegram_webhook'),
    path('logout/', views.logout_view, name='logout'),
]