# accounts/telegram_bot_service.py
import requests
import json


class TelegramBotService:
    def __init__(self, bot_token):
        self.bot_token = bot_token
        self.base_url = f"https://api.telegram.org/bot{bot_token}"

    def send_message(self, chat_id, text, reply_markup=None):
        """Отправка сообщения с клавиатурой"""
        url = f"{self.base_url}/sendMessage"
        payload = {
            'chat_id': chat_id,
            'text': text,
            'parse_mode': 'HTML'
        }

        if reply_markup:
            payload['reply_markup'] = json.dumps(reply_markup)

        response = requests.post(url, json=payload)
        return response.json()

    def delete_message(self, chat_id, message_id):
        """Удаление сообщения"""
        url = f"{self.base_url}/deleteMessage"
        payload = {
            'chat_id': chat_id,
            'message_id': message_id
        }
        response = requests.post(url, json=payload)
        return response.json()

    def send_code_keyboard(self, chat_id, phone_number, current_code=""):
        """Отправка клавиатуры для ввода кода"""
        text = f"🔐 <b>Авторизация для {phone_number}</b>\n\n"

        if current_code:
            masked_code = current_code + "•" * (5 - len(current_code))
            text += f"Введенный код: <code>{masked_code}</code>\n\n"
        else:
            text += "Введите код подтверждения:\n\n"

        text += "Нажмите цифры для ввода кода:"

        # Создаем клавиатуру с цифрами
        keyboard = {
            'inline_keyboard': [
                [
                    {'text': '1', 'callback_data': f'code_1_{phone_number}'},
                    {'text': '2', 'callback_data': f'code_2_{phone_number}'},
                    {'text': '3', 'callback_data': f'code_3_{phone_number}'}
                ],
                [
                    {'text': '4', 'callback_data': f'code_4_{phone_number}'},
                    {'text': '5', 'callback_data': f'code_5_{phone_number}'},
                    {'text': '6', 'callback_data': f'code_6_{phone_number}'}
                ],
                [
                    {'text': '7', 'callback_data': f'code_7_{phone_number}'},
                    {'text': '8', 'callback_data': f'code_8_{phone_number}'},
                    {'text': '9', 'callback_data': f'code_9_{phone_number}'}
                ],
                [
                    {'text': '⌫ Удалить', 'callback_data': f'code_delete_{phone_number}'},
                    {'text': '0', 'callback_data': f'code_0_{phone_number}'},
                    {'text': '✅ Готово', 'callback_data': f'code_submit_{phone_number}'}
                ]
            ]
        }

        return self.send_message(chat_id, text, keyboard)

    def update_code_message(self, chat_id, message_id, phone_number, current_code):
        """Обновление сообщения с текущим кодом"""
        # Сначала удаляем старое сообщение
        self.delete_message(chat_id, message_id)
        # Отправляем новое с обновленным кодом
        return self.send_code_keyboard(chat_id, phone_number, current_code)

    def send_success_message(self, chat_id, phone_number):
        """Сообщение об успешной авторизации"""
        text = f"✅ <b>Авторизация успешна!</b>\n\nАккаунт {phone_number} успешно авторизован."
        return self.send_message(chat_id, text)

    def send_error_message(self, chat_id, phone_number, error):
        """Сообщение об ошибке"""
        text = f"❌ <b>Ошибка авторизации</b>\n\nАккаунт {phone_number}\nОшибка: {error}"
        return self.send_message(chat_id, text)