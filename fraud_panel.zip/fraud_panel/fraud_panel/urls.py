from django.urls import path, include
from django.contrib import admin
from django.shortcuts import redirect
from django.conf import settings
from django.conf.urls.static import static

def redirect_to_dashboard(request):
    return redirect('dashboard:index')

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', redirect_to_dashboard, name='index'),  # Add this line
    path('', redirect_to_dashboard, name='home'),
    path('dashboard/', include('dashboard.urls', namespace='dashboard')),
    path('accounts/', include('accounts.urls', namespace='accounts')),
    path('bots/', include('bots.urls', namespace='bots')),
    path('auth/', include('authentication.urls', namespace='authentication')),
    path('payments/', include('payments.urls', namespace='payments')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)