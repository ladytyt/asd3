from django.core.management.base import BaseCommand
from bots.bot_runner import run_bots
import logging


class Command(BaseCommand):
    help = 'Запуск Telegram ботов'

    def handle(self, *args, **options):
        self.stdout.write(
            self.style.SUCCESS('Запуск Telegram ботов...')
        )
        try:
            run_bots()
        except KeyboardInterrupt:
            self.stdout.write(
                self.style.WARNING('Остановка ботов...')
            )
        except Exception as e:
            self.stdout.write(
                self.style.ERROR(f'Ошибка: {e}')
            )
            logging.error(f"Ошибка запуска ботов: {e}")