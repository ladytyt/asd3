from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.views.decorators.http import require_POST
from django.http import JsonResponse
from django.db.models import Q
import threading
import logging
from asgiref.sync import sync_to_async

from .models import BotTemplate, BotInstance, MailingCampaign, BotLog, MailingLog, SalesPlan, CountryPrice
from .forms import BotTemplateForm, BotInstanceForm, MailingCampaignForm, SalesPlanForm, CountryPriceFormSet, CountryPriceForm
from .bot_runner import run_bot_sync, stop_bot_sync

logger = logging.getLogger(__name__)


@login_required
def sales_plan_list(request):
    plans = SalesPlan.objects.filter(owner=request.user)

    if not plans.exists():
        messages.info(request, 'У вас еще нет планов продаж. Создайте первый план продаж для начала работы.')
        return redirect('bots:sales_plan_create')

    return render(request, 'bots/sales_plan_list.html', {'plans': plans})


@login_required
def sales_plan_create(request):
    if request.method == 'POST':
        form = SalesPlanForm(request.POST)
        formset = CountryPriceFormSet(request.POST)

        if form.is_valid() and formset.is_valid():
            sales_plan = form.save(commit=False)
            sales_plan.owner = request.user
            sales_plan.save()

            # Save country prices
            for country_form in formset:
                if country_form.cleaned_data and not country_form.cleaned_data.get('DELETE', False):
                    country_price = country_form.save(commit=False)
                    country_price.sales_plan = sales_plan
                    country_price.save()

            messages.success(request, 'План продаж успешно создан!')
            return redirect('bots:sales_plan_list')
        else:
            messages.error(request, 'Пожалуйста, исправьте ошибки в форме.')
    else:
        form = SalesPlanForm()
        formset = CountryPriceFormSet()

    return render(request, 'bots/sales_plan_form.html', {
        'form': form,
        'formset': formset,
        'countries': CountryPriceForm.COUNTRIES
    })


@login_required
def sales_plan_edit(request, pk):
    plan = get_object_or_404(SalesPlan, pk=pk, owner=request.user)

    if request.method == 'POST':
        form = SalesPlanForm(request.POST, instance=plan)
        formset = CountryPriceFormSet(request.POST, instance=plan)

        if form.is_valid() and formset.is_valid():
            form.save()
            formset.save()
            messages.success(request, 'План продаж успешно обновлен!')
            return redirect('bots:sales_plan_list')
        else:
            messages.error(request, 'Пожалуйста, исправьте ошибки в форме.')
    else:
        form = SalesPlanForm(instance=plan)
        formset = CountryPriceFormSet(instance=plan)

    return render(request, 'bots/sales_plan_form.html', {
        'form': form,
        'formset': formset,
        'countries': CountryPriceForm.COUNTRIES
    })


@login_required
def sales_plan_delete(request, pk):
    plan = get_object_or_404(SalesPlan, pk=pk, owner=request.user)

    if request.method == 'POST':
        plan_name = plan.name
        plan.delete()
        messages.success(request, f'План продаж "{plan_name}" удален!')
        return redirect('bots:sales_plan_list')

    return render(request, 'bots/sales_plan_confirm_delete.html', {'plan': plan})


@login_required
def index(request):
    templates_count = BotTemplate.objects.filter(owner=request.user).count()
    bots_count = BotInstance.objects.filter(owner=request.user, is_active=True).count()
    mailings_count = MailingCampaign.objects.filter(owner=request.user).count()
    plans_count = SalesPlan.objects.filter(owner=request.user).count()

    recent_bots = BotInstance.objects.filter(owner=request.user).order_by('-created_at')[:5]

    total_messages = BotLog.objects.filter(
        bot_instance__owner=request.user,
        action__icontains='message'
    ).count()

    context = {
        'templates_count': templates_count,
        'bots_count': bots_count,
        'mailings_count': mailings_count,
        'plans_count': plans_count,
        'recent_bots': recent_bots,
        'total_messages': total_messages,
    }
    return render(request, 'bots/index.html', context)


@login_required
def template_list(request):
    templates = BotTemplate.objects.filter(owner=request.user)

    if not templates.exists():
        messages.info(request, 'У вас еще нет шаблонов ботов. Создайте первый шаблон для начала работы.')
        return redirect('bots:template_create')

    search_query = request.GET.get('search', '')
    if search_query:
        templates = templates.filter(name__icontains=search_query)

    return render(request, 'bots/template_list.html', {
        'templates': templates,
        'search_query': search_query
    })


@login_required
def template_create(request):
    if request.method == 'POST':
        form = BotTemplateForm(request.POST, request.FILES)
        if form.is_valid():
            template = form.save(commit=False)
            template.owner = request.user
            template.save()
            messages.success(request, 'Шаблон успешно создан!')
            return redirect('bots:template_list')
        else:
            messages.error(request, 'Пожалуйста, исправьте ошибки в форме.')
    else:
        form = BotTemplateForm()

    return render(request, 'bots/template_form.html', {'form': form})


@login_required
def template_edit(request, pk):
    template = get_object_or_404(BotTemplate, pk=pk, owner=request.user)

    if request.method == 'POST':
        form = BotTemplateForm(request.POST, request.FILES, instance=template)
        if form.is_valid():
            form.save()
            messages.success(request, 'Шаблон успешно обновлен!')
            return redirect('bots:template_list')
        else:
            messages.error(request, 'Пожалуйста, исправьте ошибки в форме.')
    else:
        form = BotTemplateForm(instance=template)

    return render(request, 'bots/template_form.html', {'form': form})


@login_required
def template_delete(request, pk):
    template = get_object_or_404(BotTemplate, pk=pk, owner=request.user)

    if request.method == 'POST':
        template_name = template.name
        template.delete()
        messages.success(request, f'Шаблон "{template_name}" удален!')
        return redirect('bots:template_list')

    return render(request, 'bots/template_confirm_delete.html', {'template': template})


@login_required
def bot_list(request):
    bots = BotInstance.objects.filter(owner=request.user)

    running_bots_count = bots.filter(is_running=True).count()
    web_bots_count = bots.filter(auth_method='web').count()
    classic_bots_count = bots.filter(auth_method='classic').count()

    context = {
        'bots': bots,
        'running_bots_count': running_bots_count,
        'web_bots_count': web_bots_count,
        'classic_bots_count': classic_bots_count,
    }

    return render(request, 'bots/bot_list.html', context)


@login_required
def bot_create(request):
    if request.method == 'POST':
        form = BotInstanceForm(request.POST, user=request.user)

        if form.is_valid():
            bot = form.save(commit=False)
            bot.owner = request.user

            auth_method = form.cleaned_data.get('auth_method', 'classic')
            bot.auth_method = auth_method

            if auth_method == 'web':
                webapp_url = form.cleaned_data.get('webapp_url', '').strip()
                webapp_button_text = form.cleaned_data.get('webapp_button_text', '🔐 Авторизоваться').strip()

                bot.webapp_url = webapp_url
                bot.webapp_button_text = webapp_button_text

            bot.save()

            BotLog.objects.create(
                bot_instance=bot,
                level='SUCCESS',
                action='BOT_CREATED',
                details=f'Бот создан с методом авторизации: {bot.get_auth_method_display()}'
            )

            messages.success(request, 'Бот успешно создан!')
            return redirect('bots:bot_list')
        else:
            messages.error(request, 'Пожалуйста, исправьте ошибки в форме.')
    else:
        form = BotInstanceForm(user=request.user)

    # Проверка наличия шаблонов
    if not BotTemplate.objects.filter(owner=request.user).exists():
        messages.warning(request, 'Сначала создайте шаблон бота перед созданием бота.')
        return redirect('bots:template_create')

    # Проверка наличия планов продаж
    if not SalesPlan.objects.filter(owner=request.user).exists():
        messages.warning(request, 'Сначала создайте план продаж перед созданием бота.')
        return redirect('bots:sales_plan_create')

    return render(request, 'bots/bot_form.html', {'form': form})


@login_required
def bot_edit(request, pk):
    bot = get_object_or_404(BotInstance, pk=pk, owner=request.user)

    if request.method == 'POST':
        form = BotInstanceForm(request.POST, instance=bot, user=request.user)
        if form.is_valid():
            updated_bot = form.save(commit=False)

            if updated_bot.auth_method == 'web' and not updated_bot.webapp_url:
                messages.error(request, 'Для Web авторизации необходимо указать Web App URL')
                return render(request, 'bots/bot_form.html', {'form': form})

            updated_bot.save()

            BotLog.objects.create(
                bot_instance=updated_bot,
                level='SUCCESS',
                action='BOT_UPDATED',
                details='Настройки бота обновлены'
            )

            messages.success(request, 'Бот успешно обновлен!')
            return redirect('bots:bot_list')
    else:
        form = BotInstanceForm(instance=bot, user=request.user)

    return render(request, 'bots/bot_form.html', {'form': form})


@login_required
def bot_delete(request, pk):
    bot = get_object_or_404(BotInstance, pk=pk, owner=request.user)

    if request.method == 'POST':
        bot_name = bot.name

        if bot.is_running:
            try:
                stop_bot_sync(bot.token)
            except Exception as e:
                logger.error(f"Ошибка остановки бота при удалении: {e}")

        bot.delete()
        messages.success(request, f'Бот "{bot_name}" удален!')
        return redirect('bots:bot_list')

    return render(request, 'bots/bot_confirm_delete.html', {'bot': bot})


@login_required
@require_POST
def bot_start(request, pk):
    bot = get_object_or_404(BotInstance, pk=pk, owner=request.user)
    try:
        def run_bot():
            try:
                run_bot_sync(bot)
            except Exception as e:
                logger.error(f"Ошибка запуска бота: {e}")
                bot.is_running = False
                bot.error_message = str(e)
                bot.save()

        thread = threading.Thread(target=run_bot)
        thread.daemon = True
        thread.start()

        BotLog.objects.create(
            bot_instance=bot,
            level='SUCCESS',
            action='BOT_STARTED',
            details='Бот запущен'
        )

        messages.success(request, f'Бот "{bot.name}" запущен')
    except Exception as e:
        logger.error(f"Ошибка запуска бота: {e}")
        messages.error(request, f'Ошибка запуска бота: {e}')

    return redirect('bots:bot_list')


@login_required
@require_POST
def bot_stop(request, pk):
    bot = get_object_or_404(BotInstance, pk=pk, owner=request.user)
    try:
        bot.is_running = False
        bot.save()

        stop_bot_sync(bot.token)

        BotLog.objects.create(
            bot_instance=bot,
            level='INFO',
            action='BOT_STOPPED',
            details='Бот остановлен'
        )

        messages.success(request, f'Бот "{bot.name}" остановлен')
    except Exception as e:
        logger.error(f"Ошибка остановки бота: {e}")
        messages.error(request, f'Ошибка остановки бота: {e}')

    return redirect('bots:bot_list')


@login_required
@require_POST
def start_all_bots(request):
    active_bots = BotInstance.objects.filter(owner=request.user, is_active=True)
    started_count = 0

    for bot in active_bots:
        try:
            bot.is_running = True
            bot.save()

            def run_bot(b=bot):
                try:
                    run_bot_sync(b)
                except Exception as e:
                    logger.error(f"Ошибка запуска бота {b.name}: {e}")
                    b.is_running = False
                    b.save()

            thread = threading.Thread(target=run_bot)
            thread.daemon = True
            thread.start()
            started_count += 1

            BotLog.objects.create(
                bot_instance=bot,
                level='SUCCESS',
                action='BOT_STARTED',
                details='Бот запущен через массовый запуск'
            )

        except Exception as e:
            logger.error(f"Ошибка запуска бота {bot.name}: {e}")

    messages.success(request, f'Запущено {started_count} ботов')
    return redirect('bots:bot_list')


@login_required
@require_POST
def stop_all_bots(request):
    active_bots = BotInstance.objects.filter(owner=request.user, is_active=True)
    stopped_count = 0

    for bot in active_bots:
        try:
            bot.is_running = False
            bot.save()

            stop_bot_sync(bot.token)
            stopped_count += 1

            BotLog.objects.create(
                bot_instance=bot,
                level='INFO',
                action='BOT_STOPPED',
                details='Бот остановлен через массовую остановку'
            )

        except Exception as e:
            logger.error(f"Ошибка остановки бота {bot.name}: {e}")

    messages.success(request, f'Остановлено {stopped_count} ботов')
    return redirect('bots:bot_list')


@login_required
@require_POST
def clean_banned_bots(request):
    bot_id = request.POST.get('bot_id')
    if bot_id:
        bot = get_object_or_404(BotInstance, pk=bot_id, owner=request.user)

        banned_logs = BotLog.objects.filter(
            bot_instance=bot,
            level='ERROR',
            details__icontains='ban'
        )

        cleaned_count = banned_logs.count()
        banned_logs.delete()

        BotLog.objects.create(
            bot_instance=bot,
            level='INFO',
            action='CLEAN_BANNED',
            details=f'Очищено {cleaned_count} записей о забаненных ботах'
        )

        messages.success(request, f'Забаненные боты для "{bot.name}" очищены ({cleaned_count} записей)')
    else:
        user_bots = BotInstance.objects.filter(owner=request.user)
        total_cleaned = 0

        for bot in user_bots:
            banned_logs = BotLog.objects.filter(
                bot_instance=bot,
                level='ERROR',
                details__icontains='ban'
            )
            cleaned_count = banned_logs.count()
            banned_logs.delete()
            total_cleaned += cleaned_count

            if cleaned_count > 0:
                BotLog.objects.create(
                    bot_instance=bot,
                    level='INFO',
                    action='CLEAN_BANNED',
                    details=f'Очищено {cleaned_count} записей о забаненных ботах'
                )

        messages.success(request, f'Очищено {total_cleaned} записей о забаненных ботах')

    return redirect('bots:bot_list')


@login_required
def mailing_list(request):
    mailings = MailingCampaign.objects.filter(owner=request.user)
    search_query = request.GET.get('search', '')
    if search_query:
        mailings = mailings.filter(name__icontains=search_query)

    return render(request, 'bots/mailing_list.html', {
        'mailings': mailings,
        'search_query': search_query
    })


@login_required
def mailing_create(request):
    if request.method == 'POST':
        form = MailingCampaignForm(request.POST)
        if form.is_valid():
            mailing = form.save(commit=False)
            mailing.owner = request.user
            mailing.save()
            form.save_m2m()

            MailingLog.objects.create(
                mailing_campaign=mailing,
                bot_instance=None,
                status='CREATED',
                details='Рассылка создана'
            )

            messages.success(request, 'Рассылка создана!')
            return redirect('bots:mailing_list')
        else:
            messages.error(request, 'Пожалуйста, исправьте ошибки в форме.')
    else:
        form = MailingCampaignForm()
        form.fields['bots'].queryset = BotInstance.objects.filter(owner=request.user, is_active=True)

    return render(request, 'bots/mailing_form.html', {'form': form})


@login_required
def mailing_preview(request):
    return render(request, 'bots/mailing_preview.html')