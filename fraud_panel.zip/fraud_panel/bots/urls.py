from django.urls import path
from django.views.generic import TemplateView
from . import views

app_name = 'bots'

urlpatterns = [
    path('', views.index, name='index'),
    path('sales-plans/', views.sales_plan_list, name='sales_plan_list'),
    path('sales-plans/create/', views.sales_plan_create, name='sales_plan_create'),
    path('sales-plans/<int:pk>/edit/', views.sales_plan_edit, name='sales_plan_edit'),
    path('sales-plans/<int:pk>/delete/', views.sales_plan_delete, name='sales_plan_delete'),
    path('templates/', views.template_list, name='template_list'),
    path('templates/create/', views.template_create, name='template_create'),
    path('templates/<int:pk>/edit/', views.template_edit, name='template_edit'),
    path('templates/<int:pk>/delete/', views.template_delete, name='template_delete'),
    path('bots/', views.bot_list, name='bot_list'),
    path('bots/create/', views.bot_create, name='bot_create'),
    path('bots/<int:pk>/edit/', views.bot_edit, name='bot_edit'),
    path('bots/<int:pk>/delete/', views.bot_delete, name='bot_delete'),
    path('bots/<int:pk>/start/', views.bot_start, name='bot_start'),
    path('bots/<int:pk>/stop/', views.bot_stop, name='bot_stop'),
    path('bots/start-all/', views.start_all_bots, name='start_all_bots'),
    path('bots/stop-all/', views.stop_all_bots, name='stop_all_bots'),
    path('bots/clean-banned/', views.clean_banned_bots, name='clean_banned_bots'),
    path('mailing/', views.mailing_list, name='mailing_list'),
    path('mailing/create/', views.mailing_create, name='mailing_create'),
    path('mailing/preview/', views.mailing_preview, name='mailing_preview'),
    path('webapp/auth/', TemplateView.as_view(template_name='webapp/auth.html'), name='webapp_auth'),
]