from django.db import models
from django.contrib.auth.models import User
from accounts.models import Account


class FinancialLog(models.Model):
    ACTION_CHOICES = [
        ('EARNED', 'Earned'),
        ('WITHDRAWN', 'Withdrawn'),
        ('TRANSFER', 'Transfer'),
        ('DONATION', 'Donation'),
    ]

    STATUS_CHOICES = [
        ('PENDING', 'Pending'),
        ('COMPLETED', 'Completed'),
        ('FAILED', 'Failed'),
    ]

    owner = models.ForeignKey(User, on_delete=models.CASCADE)
    account = models.ForeignKey(Account, on_delete=models.CASCADE, null=True, blank=True)
    action = models.CharField(max_length=20, choices=ACTION_CHOICES, verbose_name="Действие")
    amount = models.DecimalField(max_digits=15, decimal_places=2, verbose_name="Сумма")
    description = models.TextField(blank=True, verbose_name="Описание")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='PENDING', verbose_name="Статус")
    timestamp = models.DateTimeField(auto_now_add=True, verbose_name="Время")
    is_valid = models.BooleanField(default=True, verbose_name="Валидность")

    def __str__(self):
        return f"{self.get_action_display()} - ${self.amount}"

    class Meta:
        ordering = ['-timestamp']
        verbose_name = 'Финансовая операция'
        verbose_name_plural = 'Финансовые операции'


class WithdrawalMethod(models.Model):
    METHOD_CHOICES = [
        ('CRYPTOBOT', 'CryptoBot'),
        ('WALLET', 'Wallet'),
        ('XROCKET', 'XRocket'),
        ('BITPAPA', 'BitPapa'),
    ]

    owner = models.ForeignKey(User, on_delete=models.CASCADE)
    method = models.CharField(max_length=20, choices=METHOD_CHOICES, verbose_name="Метод")
    min_amount = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Минимальная сумма")
    max_amount = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Максимальная сумма")
    is_active = models.BooleanField(default=True, verbose_name="Активен")

    def __str__(self):
        return f"{self.get_method_display()} ({self.min_amount}-{self.max_amount})"

    class Meta:
        verbose_name = 'Метод вывода'
        verbose_name_plural = 'Методы вывода'