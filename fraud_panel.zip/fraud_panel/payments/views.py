from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import FinancialLog, WithdrawalMethod


@login_required
def index(request):
    financial_logs = FinancialLog.objects.filter(owner=request.user).order_by('-timestamp')[:50]
    withdrawal_methods = WithdrawalMethod.objects.filter(owner=request.user, is_active=True)

    # Статистика
    total_earned = FinancialLog.objects.filter(
        owner=request.user,
        action='EARNED',
        status='COMPLETED'
    ).aggregate(total=Sum('amount'))['total'] or 0

    total_withdrawn = FinancialLog.objects.filter(
        owner=request.user,
        action='WITHDRAWN',
        status='COMPLETED'
    ).aggregate(total=Sum('amount'))['total'] or 0

    context = {
        'financial_logs': financial_logs,
        'withdrawal_methods': withdrawal_methods,
        'total_earned': total_earned,
        'total_withdrawn': total_withdrawn,
        'balance': total_earned - total_withdrawn,
    }

    return render(request, 'payments/index.html', context)